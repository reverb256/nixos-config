# Distributed build machines configuration
# Format: user@host store-path system-features - max-jobs
''
  root@zephyr /nix/store x86_64-linux - 32
  root@nexus /nix/store x86_64-linux - 8
  root@forge /nix/store x86_64-linux - 3
  root@sentry /nix/store x86_64-linux - 8
''
