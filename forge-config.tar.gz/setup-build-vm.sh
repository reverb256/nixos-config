#!/bin/bash
set -e

echo "🧪 Setting up Build VM for AI Agent Smart Fish Shell Testing"
echo "============================================================"

cat > vm-config.nix << 'EOF'
{ config, pkgs, ... }:
{
  imports = [ 
    ./modules/ai-agent-smart-fish.nix 
  ];
  
  boot.loader.systemd-boot.enable = true;
  boot.loader.efi.canTouchEfiVariables = true;
  
  services.openssh.enable = true;
  services.openssh.permitRootLogin = "yes";
  
  users.users.vmuser = {
    isNormalUser = true;
    extraGroups = ["wheel"];
    shell = pkgs.fish;
    initialPassword = "test123";
  };
  
  networking.hostName = "ai-fish-test";
  networking.firewall.enable = false;
  
  environment.systemPackages = with pkgs; [ 
    opencode
    git
    curl
    wget
  ];
  
  programs.fish.enable = true;
}
EOF

mkdir -p test-projects/{nextjs,rust,python,nixos,ai-project}

cat > test-projects/nextjs/package.json << 'EOF'
{
  "name": "test-nextjs",
  "version": "1.0.0",
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "test": "jest"
  }
}
EOF
echo 'module.exports = {};' > test-projects/nextjs/next.config.js

cat > test-projects/rust/Cargo.toml << 'EOF'
[package]
name = "test-rust"
version = "0.1.0"
edition = "2021"
EOF
mkdir -p test-projects/rust/src && echo 'fn main() { println!("Hello, world!"); }' > test-projects/rust/src/main.rs

cat > test-projects/python/requirements.txt << 'EOF'
flask==2.3.3
requests==2.31.0
EOF
echo 'print("Hello from Python!")' > test-projects/python/main.py

echo '{ config, pkgs, ... }: { config = {}; }' > test-projects/nixos/default.nix

echo '{"ai-config": true}' > test-projects/ai-project/.ai-config

echo "✅ VM configuration created"
echo "📁 Test projects structure:"
find test-projects -name "package.json" -o -name "Cargo.toml" -o -name "requirements.txt" -o -name "default.nix" -o -name ".ai-config"

echo ""
echo "🚀 Build VM Commands:"
echo "===================="
echo "# Build the VM"
echo "nixos-rebuild build --flake .#vm-config"
echo ""
echo "# Launch VM (if using QEMU)"
echo "qemu-system-x86_64 -enable-kvm -m 4G -hda ./result/nixos.qcow2"
echo ""
echo "# Or use nixos-shell"
echo "nix run nixos-shell -- --flake .#vm-config"
echo ""
echo "🧪 Test Commands (inside VM):"
echo "=============================="
echo "fish -c 'ai-info'                     # Test AI info command"
echo "fish -c 'smart-project-info'          # Test project info"
echo "cd test-projects/nextjs && ai-info    # Test Next.js detection"
echo "cd test-projects/rust && ai-info      # Test Rust detection"
echo "opencode 'Run dev server'             # Test opencode integration"
echo ""
echo "🎯 Ready to test AI Agent Smart Fish Shell!"