{pkgs, ...}: {

  # NVIDIA configuration for RTX 3090 (use proprietary drivers with stable)
  hardware.nvidia = {
    package = pkgs.linuxPackages.nvidiaPackages.stable;
    modesetting.enable = true;
    open = false;
  };
  nixpkgs.config.allowUnfree = true;
  nixpkgs.config.cudaSupport = false;

  # Apply mining overlay
  nixpkgs.overlays = [
    (import ./modules/mining-overlay.nix)
  ];

  # ============================================================================
  # PASSWORDLESS MINING CONTROL - Allow user to control mining services without password
  # ============================================================================

  # Allow j_kro to control mining services without password (for desktop icons)
  security.sudo.extraRules = [
    {
      users = ["j_kro"];
      commands = [
        {
          command = "/run/current-system/sw/bin/systemctl start lolminer-nvidia.service";
          options = ["NOPASSWD"];
        }
        {
          command = "/run/current-system/sw/bin/systemctl stop lolminer-nvidia.service";
          options = ["NOPASSWD"];
        }
        {
          command = "/run/current-system/sw/bin/systemctl start xmrig.service";
          options = ["NOPASSWD"];
        }
        {
          command = "/run/current-system/sw/bin/systemctl stop xmrig.service";
          options = ["NOPASSWD"];
        }
        {
          command = "/run/current-system/sw/bin/systemctl status lolminer-nvidia.service";
          options = ["NOPASSWD"];
        }
        {
          command = "/run/current-system/sw/bin/systemctl status xmrig.service";
          options = ["NOPASSWD"];
        }
      ];
    }
  ];

   # ============================================================================
   # BLUETOOTH SUPPORT
   # ============================================================================

   # Enable Bluetooth
   hardware.bluetooth = {
     enable = true;
     powerOnBoot = true;
   };

   # ============================================================================
   # NIX CONFIGURATION - Experimental features, build optimization, and caching
   # ============================================================================
   nix = {
    settings = {
      # Enable experimental Nix features
      experimental-features = ["nix-command" "flakes"];

      # Phase 1: Nix build optimization for Ryzen 5950X
      max-jobs = 8; # Parallel derivations (use ~1/2 of threads)
      cores = 16; # Cores per derivation (use ~1/2 of cores)

      # 5-tier binary caching + CUDA cache
      substituters = [
        "https://cache.nixos.org"
        "https://nix-community.cachix.org"
        "https://ezkea.cachix.org"
        "https://nixpkgs-wayland.cachix.org"
        "https://nix-gaming.cachix.org"
        "https://cuda-maintainers.cachix.org"
      ];
      trusted-public-keys = [
        "cache.nixos.org-1:6NCHdD59X431o0gWypbMrAURkbJ16ZPMQFGspcDShjY="
        "nix-community.cachix.org-1:mB9FSh9qf2dCimDSUo8Zy7bkq5CX+/rkCWyvRCYg3Fs="
        "ezkea.cachix.org-1:ioBmUbJTZIKsHmWWXPe1FSFbeVe+afhfgqgTSNd34eI="
        "nixpkgs-wayland.cachix.org-1:3lwxaILxMRkVhehr5StQprHdEo4IrE8sRho9R9HOLYA="
        "nix-gaming.cachix.org-1:vn/szNT7r/Pc1FbcBjRGHLk7XNk0v2KvMq2v7EwXQ8w="
        "cuda-maintainers.cachix.org-1:0dq3bujKpuEPMCX6U4WylrUDZ9JyUG0VpVZa7CNfq5E="
      ];
    };
  };

  # ============================================================================
  # SYSTEMD SLICES - Workload isolation for gaming, mining, and builds
  # ============================================================================
  systemd = {
    # Systemd slices for workload prioritization
    slices = {
      # Systemd slice for nix builds to prevent user responsiveness degradation
      "nix.slice" = {
        description = "Nix build processes slice";
        sliceConfig = {
          MemoryHigh = "80%"; # Limit memory usage
          CPUQuota = "80%"; # Limit CPU usage
        };
      };

      # High-priority gaming slice for VR and gaming applications
      "gaming.slice" = {
        description = "Gaming applications slice";
        sliceConfig = {
          MemoryHigh = "90%"; # High memory priority for games
          CPUQuota = "95%"; # High CPU priority for games
          CPUAccounting = "yes";
          MemoryAccounting = "yes";
          TasksAccounting = "yes";
          TasksMax = 20000;
        };
      };

      # Mining slice with lower priority to avoid interfering with gaming
      "mining.slice" = {
        description = "Mining processes slice";
        sliceConfig = {
          MemoryHigh = "50%"; # Limit mining memory usage
          CPUQuota = "60%"; # Limit mining CPU usage during gaming
          CPUAccounting = "yes";
          MemoryAccounting = "yes";
          TasksAccounting = "yes";
          TasksMax = 10000;
        };
      };
    };

    # Nix daemon service configuration
    services.nix-daemon.serviceConfig.Slice = "nix.slice";
  };

   imports = [
     # Custom modules
     ./modules/base.nix
     ./modules/desktop.nix
     ./modules/users.nix
     ./modules/nix-config.nix
     ./modules/system-packages.nix
     ./modules/environment.nix
     ./modules/ssh.nix
     ./modules/systemd-slices.nix
     ./modules/networking-shared.nix
     ./modules/mining.nix
     ./modules/storage.nix
     ./modules/gaming.nix

     # Hardware configuration (DO NOT EDIT)
     ./hardware-configuration.nix
   ];

  # Direct service definitions to ensure they work
  services.mining.enable = true;
  services.mining.xmrig.enable = true;
  services.mining.lolminer.enable = true;
  
  # Thread allocation for mining services
  services.mining.xmrig.threads = 4;  # System service: 4 threads
  # User instance will use remaining 12 threads (16 - 4 = 12)

  # ============================================================================
  # BOOT CONFIGURATION - Bootloader and kernel parameters
  # ============================================================================
  boot = {
    # Bootloader configuration
    loader = {
      systemd-boot.enable = true;
      efi.canTouchEfiVariables = true;
    };

    # Phase 1: Foundation - High-performance kernel parameters
    kernelParams = [
      # Wine gaming performance
      "fsync.enable=1"

      # NVIDIA optimizations
      "nvidia-drm.modeset=1"
      "threadirqs"

      # Ryzen 5950X optimizations
      "amd_pstate=active"
      "mitigations=off"
      "transparent_hugepage=madvise"
      "numa_balancing=disable"
      "nowatchdog"

      # PCIe and I/O optimizations
      "pcie_aspm=off"
      "elevator=none"

      # High-priority gaming optimizations
      "isolcpus=managed_applications" # CPU isolation for gaming
      "nohz_full=1-15" # Disable tick on application cores
      "rcu_nocbs=1-15" # RCU offload for low latency
    ];
  };

  # ============================================================================
  # NETWORKING CONFIGURATION
  # ============================================================================

  

  # Phase 1: CPU governor for gaming performance
  powerManagement.cpuFreqGovernor = "performance";

  # Phase 1: Memory management optimizations
  zramSwap = {
    enable = true;
    memoryPercent = 50;
    algorithm = "zstd";
  };

  # Phase 1: OOM daemon for memory pressure management
  systemd.oomd = {
    enable = true;
    enableRootSlice = true;
    enableSystemSlice = true;
  };

  # ============================================================================
  # TIMEZONE AND LOCALE
  # ============================================================================

  time.timeZone = "America/Winnipeg";
  i18n.defaultLocale = "en_CA.UTF-8";
  i18n.extraLocaleSettings = {
    LC_ADDRESS = "en_CA.UTF-8";
    LC_IDENTIFICATION = "en_CA.UTF-8";
    LC_MEASUREMENT = "en_CA.UTF-8";
    LC_MONETARY = "en_CA.UTF-8";
    LC_NAME = "en_CA.UTF-8";
    LC_NUMERIC = "en_CA.UTF-8";
    LC_PAPER = "en_CA.UTF-8";
    LC_TELEPHONE = "en_CA.UTF-8";
    LC_TIME = "en_CA.UTF-8";
  };

  # ============================================================================
  # USERS AND GROUPS
  # Users configured in modules/users.nix

  # Fonts configured in defaults

  # ============================================================================
  # SERVICES CONFIGURATION
  # ============================================================================
  services = {
    # X11/WAYLAND DESKTOP ENVIRONMENT
    xserver.enable = true;
    displayManager = {
      sddm.enable = true;
      autoLogin = {
        enable = true;
        user = "j_kro";
      };
    };
    desktopManager.plasma6.enable = true;

    # ============================================================================
    # SOUND CONFIGURATION
    # ============================================================================
    pulseaudio.enable = false;
    pipewire = {
      enable = true;
      alsa.enable = true;
      alsa.support32Bit = true;
      pulse.enable = true;
      jack.enable = true;
    };

    # ============================================================================
    # PRINTER SUPPORT
    # ============================================================================
    # PRINTER SUPPORT
    # ============================================================================
    printing.enable = true;
    avahi = {
      enable = true;
      nssmdns4 = true;
      openFirewall = true;
    };

    # SSH configured in modules/ssh.nix

    # ============================================================================
    # NVIDIA DRIVERS AND HARDWARE SUPPORT
    # ============================================================================
    xserver.videoDrivers = ["nvidia"];

    # ============================================================================
    # SYSTEM SERVICES
    # ============================================================================
    mysql = {
      enable = true;
      package = pkgs.mariadb;
    };
    redis.servers."".enable = true;
    postgresql.enable = true;

    

    # ============================================================================
    # FLATPAK (DISABLED)
    # ============================================================================
    flatpak.enable = true;
  };

  # ============================================================================
  # SYSTEMD SERVICES - Shader caching and other custom services
  # ============================================================================
  systemd.services = {
    # ============================================================================
    # SHADER PRE-CACHING SERVICES (DISABLED - glxinfo not available)
    # ============================================================================
    # nvidia-shader-cache = {
    #   description = "NVIDIA Shader Pre-Caching";
    #   serviceConfig = {
    #     Type = "oneshot";
    #     ExecStart = "${pkgs.mesa}/bin/glxinfo";
    #     RemainAfterExit = "yes";
    #   };
    #   wantedBy = ["multi-user.target"];
    # };

    # NVIDIA shader cache service with proper dependencies
    nvidia-shader-cache-manager = {
      description = "NVIDIA Shader Cache Manager";
      serviceConfig = {
        Type = "oneshot";
        ExecStart = ''
          #!/bin/bash
          # Create shader cache directory
          mkdir -p /var/cache/nvidia/shader
          # Shader pre-caching disabled - glxinfo not available in current nixpkgs
          echo "Shader cache directory created" > /var/cache/nvidia/shader/init.log
        '';
        RemainAfterExit = "yes";
      };
      wantedBy = ["graphical-session.target"];
    };
  };

  # ============================================================================
  # HARDWARE CONFIGURATION
  # ============================================================================
  hardware.graphics = {
    enable = true;
    enable32Bit = true; # 32-bit support for Steam/VR
  };

  # ============================================================================
  # VIRTUALIZATION SUPPORT
  # ============================================================================
  virtualisation.libvirtd.enable = true;

  # ============================================================================
  # PROGRAMS CONFIGURATION
  # ============================================================================

  # ============================================================================
  # PROGRAMS CONFIGURATION
  # ============================================================================
  programs = {
    # ============================================================================
    # SHELL CONFIGURATION
    # ============================================================================
    fish = {
      enable = true;
      useBabelfish = true; # Translate shell aliases
      vendor = {
        completions.enable = true;
        config.enable = true;
        functions.enable = true;
      };
    };

    # ============================================================================
    # ANIME GAME LAUNCHERS
    # ============================================================================
    anime-game-launcher.enable = true; # Genshin Impact (AGL)
    honkers-railway-launcher.enable = true; # Honkai: Star Rail (AGL)
    sleepy-launcher.enable = true; # Zenless Zone Zero
  };

  # ============================================================================
  # PHASE 1: SYSCTL OPTIMIZATIONS FOR GAMING
  # ============================================================================

  boot.kernel.sysctl = {
    # Network optimizations for gaming
    "net.core.rmem_max" = 2500000;
    "net.core.wmem_max" = 2500000;

    # Memory management
    "vm.swappiness" = 10;
    "vm.vfs_cache_pressure" = 50;

    # CPU scheduler optimizations
    "kernel.sched_min_granularity_ns" = 10000000;
    "kernel.sched_wakeup_granularity_ns" = 15000000;
    "kernel.sched_migration_cost_ns" = 500000;

    # High-priority gaming sysctl optimizations
    "kernel.sched_autogroup_enabled" = 0; # Disable autogroups for lower latency
    "kernel.sched_child_runs_first" = 0; # Allow parent to run first
    "kernel.sched_ttwu_protect" = 1; # Protect wakeups
    "kernel.sched_min_runtime" = 5000000; # Minimum runtime per slice
    "vm.dirty_ratio" = 5; # Reduce dirty page ratio
    "vm.dirty_background_ratio" = 2; # Reduce dirty background ratio
    "vm.dirty_expire_centisecs" = 100; # Faster dirty page expiration
    "vm.dirty_writeback_centisecs" = 50; # Faster writeback
    "kernel.timer_migration" = 1; # Allow timer migration
    "kernel.perf_event_paranoid" = -1; # Allow perf monitoring
  };

  # ============================================================================
  # SYSTEM ENVIRONMENT VARIABLES
  # ============================================================================

  environment.sessionVariables = {
    EDITOR = "nvim";
    BROWSER = "zen";
    NIXOS_OZONE_WL = "1";
    GBM_BACKEND = "nvidia-drm";
    __GLX_VENDOR_LIBRARY_NAME = "nvidia";
    WLR_NO_HARDWARE_CURSORS = "1";
    WLR_EGL_NO_MODIFIERS = "1";
    STEAM_RUNTIME = "1";
    # Claude Code with KAT-Coder-Pro-v1
    ANTHROPIC_BASE_URL = "https://vanchin.streamlake.ai/api/gateway/coding/kat-coder-pro-v1/claude-code-proxy";
    ANTHROPIC_AUTH_TOKEN = "7g8GggMc8eK7CotJoXxzEA5chtvgv8eMgyEAzNjEMM4";
    API_TIMEOUT_MS = "3000000";
  };

   # Hostname
   networking.hostName = "zephyr";

   system.stateVersion = "26.05";
}
