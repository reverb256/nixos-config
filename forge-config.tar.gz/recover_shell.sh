#!/nix/store/*-bash-*/bin/bash
# Recovery script - use absolute nix store paths

# Set proper PATH
export PATH="/run/current-system/sw/bin:/usr/bin:/bin"

# Verify we have working commands
echo "Testing PATH..."
ls /run/current-system/sw/bin | head -5

# If nixos-rebuild exists, run it
if [ -x "/run/current-system/sw/bin/nixos-rebuild" ]; then
    echo "Running nixos-rebuild..."
    cd /etc/nixos-cleanup
    /run/current-system/sw/bin/sudo /run/current-system/sw/bin/nixos-rebuild switch --flake .#zephyr
else
    echo "nixos-rebuild not found in system profile"
    echo "Checking alternative locations..."
    find /nix/store -name nixos-rebuild -type f 2>/dev/null | head -3
fi
