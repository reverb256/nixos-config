#!/usr/bin/env bash

# Update flake.nix with correct zen-browser key
echo "Updating flake.nix with correct zen-browser key..."

# Backup current flake
cp /etc/nixos/flake.nix.bak

# Get the latest zen-browser flake
curl -s https://raw.githubusercontent.com/0xc000022070/zen-browser-flake/main/flake.nix > /tmp/zen-browser-flake-new.nix

# Update flake.nix with corrected key
sed 's/"trusted-substitutors.*=.*"/s/"$2d" -i -e "s/https://zen-browser.cachix.org/b$2/""

# Replace the key line
sed -i "/s/\"trusted-substituters.*=.*\"/\"s/"$2/" -i "s/\"trusted-public-keys.*=.*\"/\"s/\"/" -i "s/\"zen-browser.cachix.org/b$2\"/""

echo "Flake updated with zen-browser key: $(grep -o "zen-browser.cachix.org/b$2" | grep "zen-browser.cachix.org/b$2:" | grep "zen-browser.cachix.org/b$2:" | cut -d':' -f1)

# Update to use the correct key format
cd /etc/nixos && cp /etc/nixos/flake.nix.bak /etc/nixos/flake.nix && echo "Rebuilding with updated flake..."