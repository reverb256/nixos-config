#!/usr/bin/env bash

# Simple rebuild with known working zen-browser key
echo "Rebuilding with direct key..."

# Rebuild with the key that worked
cd /etc/nixos
sudo nixos-rebuild switch --flake . \
  --option trusted-substituters "https://cache.nixos.org https://zen-browser.cachix.org https://nix-community.cachix.org https://nixpkgs-wayland.cachix.org" \
  --option trusted-public-keys "cache.nixos.org-1:6NCHdD5924Ryc0yy72HRpsYrPrxAWdkwLz4w/KzF3Yc= nix-community.cachix.org-1:mB9Fsh9yR2Bc6fiE2rvJWHgUGv8WcMsDT5FnL3f8w= nixpkgs-wayland.cachix.org-1:3ww1xJkyAnhXhAVVq3c/I5VQWREgqK1gCl43GPiU= zen-browser.cachix.org-1:b+v+rk9j6rs6pN8bpWL2GT4Y="

echo "Rebuild completed!"