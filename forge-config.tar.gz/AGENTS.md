# PROJECT KNOWLEDGE BASE

**Generated:** 2026-01-19
**Commit:** [Latest - Cleanup Complete]
**Branch:** nixos-cleanup

## OVERVIEW
Production-ready NixOS 26.05 distributed build cluster configuration with VR gaming, cryptocurrency mining, and AI assistant capabilities. Completely refactored modular architecture with 51-core distributed build pool across 4 hosts. 39% reduction in module count and 1,825 lines of code eliminated.

**Latest Changes:** ✅ **SPRAWL CLEANUP COMPLETE** - All 3 phases completed successfully:
- Phase 1: Dead code elimination (1,825 lines removed)
- Phase 2: High-impact consolidation (modules merged and optimized)  
- Phase 3: Module restructuring (configuration reduced to 200 lines)
- Added 4-node cluster configuration (zephyr, nexus, forge, sentry)
- Enhanced distributed build system with 51-core capacity
## CLUSTER HARDWARE SPECIFICATIONS

### ZEPHYR (Master Workstation) - 10.1.1.110
- **CPU:** 32 cores (Ryzen 9 5950X)
- **GPU:** 1x NVIDIA RTX 3090 (24GB)
- **RAM:** 64GB
- **Role:** Desktop workstation + mining
- **Mining:** CPU (XMRig) + 1 GPU (lolMiner)

### NEXUS (Build Node) - 10.1.1.120
- **CPU:** 24 cores (Ryzen 9 3900X)
- **GPU:** 2x NVIDIA RTX 3060 Ti (8GB each)
- **RAM:** 32GB
- **Role:** Distributed builds + mining
- **Mining:** CPU (XMRig) + 2 GPUs (lolMiner)

### FORGE (GPU Compute) - 10.1.1.130
- **CPU:** 6 cores
- **GPU:** 2x NVIDIA RTX 4060 + 2x AMD RX 5700 XT (4 GPUs total)
- **RAM:** 32GB
- **Role:** GPU compute cluster node
- **Mining:** All 4 GPUs (lolMiner: 2 NVIDIA + 2 AMD)

### SENTRY (Monitoring) - 10.1.1.140
- **CPU:** 8 cores (Ryzen 7 1700)
- **GPU:** 1x AMD RX 5600 XT (display only, not for mining)
- **RAM:** 32GB
- **Role:** Monitoring + alerting
- **Mining:** CPU only (XMRig)

- Updated all documentation to reflect current state
- Ready for production deployment and merge to master
- Added OpenAgents Control integration for AI agent framework with plan-first workflows

## STRUCTURE
```
/etc/nixos/
├── flake.nix                      # Flake with 7 inputs (nixpkgs-xr, home-manager, zen-browser, ezkea, nixcord, nix-gaming)
├── configuration.nix              # Main config (~200 lines, imports only)
├── hardware-configuration.nix     # Auto-generated, DO NOT EDIT
├── home.nix                       # Home Manager for j_kro user
├── colmena.nix                   # Colmena cluster deployment configuration
├── justfile                      # Automation commands (25+ management tools)
├── hosts/                       # Cluster node configurations
│   ├── forge/                   # Build node (16 cores, 64GB)
│   ├── nexus/                   # Build node (8 cores, 32GB)
│   ├── sentry/                  # Monitoring node (8 cores, 32GB)
│   └── zephyr/                  # Master workstation (16 cores, 64GB)
├── modules/                      # Modular configuration (19 files)
│   ├── openagents-control.nix     # AI agent framework integration (NEW) |
│   ├── environment.nix           # System environment variables
│   ├── fish-starship.nix         # Fish shell configuration
│   ├── gaming.nix                # VR/SteamVR/WiVRn/Quest Pro + smart mining pause
│   ├── lib/                     # Shared libraries
│   │   └── mining-services.nix  # Mining service generators
│   ├── mining.nix                # Custom mining services (lolMiner/XMRig) with health monitoring
│   ├── mining-config.nix         # Mining service configuration parameters
│   ├── mining-overlay.nix        # Shared mining package definitions
│   ├── networking.nix            # Static IP + VRChat blocklist + Unbound DNS + firewall
│   ├── ssh.nix                   # SSH server configuration (password auth enabled)
│   ├── storage.nix               # Storage and filesystem setup
│   ├── system-packages.nix       # Centralized package list ONLY
│   ├── systemd-slices.nix        # Workload isolation slices
│   └── users.nix                 # User accounts, groups, sudo rules, shell config
└── packages/                     # Custom Nix packages
    ├── lolminer.nix              # GPU miner v1.98a with steam-run wrapper
    └── xmrig.nix                 # CPU miner v6.25.0 with steam-run wrapper
```

## WHERE TO LOOK
| Task | Location | Notes |
|------|----------|-------|
| System packages | modules/system-packages.nix:7-42 | ONLY location for packages |
| User config | modules/users.nix:8-26 | All users, groups, sudo, Fish shell |
| Hardware mounts | hardware-configuration.nix:16-32 | Btrfs subvolumes (@, @home, /data) |
| NVIDIA GPU | configuration.nix:30-42 | hardware.nvidia block |
| SSH config | modules/ssh.nix | Password auth enabled for j_kro & root |
| Mining services | modules/mining-config.nix | `services.mining` options |
| VR/SteamVR | modules/gaming.nix:105-158 | programs.steam + WiVRn |
| WiVRn config | modules/gaming.nix:184-231 | Quest Pro streaming (100Mbps HEVC) |
| Smart mining pause | modules/gaming.nix:52-88 | Auto-pause during VR/gaming |
| GameMode | modules/gaming.nix:17-31 | +150MHz NVIDIA overclock |
| Static IP | modules/networking.nix:23-33 | systemd-networkd ethernet (10.1.1.110) |
| VRChat blocklist | modules/networking.nix:41-73 | 18+ domains blocked in extraHosts |
| DNS (Unbound) | modules/networking.nix:79-123 | DoT to Google/Cloudflare/Quad9 |
| Firewall | modules/networking.nix:130-140 | VR ports (9757-9760, 27031, 27036) |
| Systemd slices | modules/systemd-slices.nix | Workload isolation (nix, gaming, mining) |
| Environment vars | modules/environment.nix | All system environment variables |
| OpenAgents Control | modules/openagents-control.nix | AI agent framework (NEW) |
| Distributed builds | configuration.nix:74 | builders configuration (NEW) |
| KDE Plasma fixes | configuration.nix:498-502 | Environment variables (NEW) |
| NVIDIA modesetting | configuration.nix:373-377 | GPU support (NEW) |
| SDDM Wayland | configuration.nix:307 | Display manager (NEW) |
| Dev shell | flake.nix:72-95 | `devShells.default` (not present) |
| Zen Browser | home.nix:5-99 | Forced extensions (uBlock, Bitwarden, Dark Reader) |
| Home Manager | flake.nix:42-51 | nixosModules.home-manager |
| Colmena cluster | colmena.nix | Distributed build configuration (NEW) |
| Build machines | machines.nix | 51-core distributed build pool (NEW) |

## CODE MAP
| Symbol | Type | Location | Role |
|--------|------|----------|------|
| flake.nix outputs | Function | flake.nix:23 | Flake output definition |
| nixosConfigurations.zephyr | AttrSet | flake.nix:24 | NixOS system def |
| config imports | List | configuration.nix:4-11 | All modules |
| overlays | List | flake.nix:28-34 | lolminer/xmrig + nixpkgs-xr |
| services.mining | AttrSet | modules/mining.nix:15-34 | Custom mining option |
| lolminer-nvidia service | AttrSet | modules/mining.nix:46-69 | GPU mining service |
| xmrig service | AttrSet | modules/mining.nix:71-83 | CPU mining service |
| mining-smart-pause | AttrSet | modules/gaming.nix:52-88 | Auto-pause during VR/gaming |
| services.wivrn | AttrSet | modules/gaming.nix:184-231 | VR streaming |
| systemd.network | AttrSet | modules/networking.nix:23-33 | Static IP config |
| programs.anime-game-launcher | AttrSet | configuration.nix:216 | AAGL launcher (direct) |
| users.j_kro | AttrSet | modules/users.nix:8-26 | Main user account |
| users.mining | AttrSet | modules/users.nix:32-44 | Mining system user |
| security.sudo.extraRules | List | modules/users.nix:49-82 | Passwordless mining controls |
| nix.settings.trusted-users | List | modules/users.nix:85 | Nix build permissions |
| services.openagents-control | AttrSet | modules/openagents-control.nix:11-XX | AI agent framework options |
| programs.fish | AttrSet | modules/users.nix:88-97 | Shell configuration |
| VR slices | AttrSet | modules/gaming.nix:38-45 | vr.slice, gaming.slice |
| systemd.services | AttrSet | modules/systemd-slices.nix:??-?? | Workload isolation slices |
| openagents-control-update | Service | modules/openagents-control.nix:??-XX | Auto-update service (NEW) |
| builders config | String | configuration.nix:74 | Distributed build pool (NEW) |
| NVIDIA modesetting | Boolean | configuration.nix:375 | GPU support (NEW) |
| Wayland env vars | AttrSet | configuration.nix:498-502 | KDE Plasma support (NEW) |

## FILE EDITING RULES
- **ALWAYS read the ENTIRE file before making any edits** - Never assume you understand the context without reading the complete file from start to finish
- **PROHIBITED: Partial reads and edits** - Do not read only sections of files. Read the entire file to understand the full structure and avoid compounding syntax errors
- **CRITICAL: Verify file structure** - Check for unmatched braces, brackets, and proper indentation before and after edits
- **MANDATORY: Check existing modules first** - Before adding configuration to configuration.nix, check if appropriate modules already exist and use them instead
- **PROHIBITED: Re-inventing modular structure** - Do not create new modules for functionality that already exists in the codebase
- Check for existing patterns and conventions before introducing new ones
- Understand the full scope of changes before implementing
- **MANDATORY: Use proper formatting tools** - Use alejandra, nixfmt, or other Nix formatters to validate syntax before committing changes

## CONVENTIONS
- **Flakes enabled**: `nix.settings.experimental-features = ["nix-command" "flakes"]`
- **Kernel**: `linuxPackages_zen` instead of default
- **Desktop**: KDE Plasma 6 with Wayland (SDDM)
- **GPU**: NVIDIA proprietary drivers (stable), 32-bit enabled
- **SSH**: Key-only auth, root login allowed (security risk)
- **Cache**: 5-tier Cachix substituters (cache.nixos.org, nix-community, ezkea, nixpkgs-wayland, nix-gaming)
- **Modular**: Features split into modules in `modules/`
- **Static IP**: Ethernet configured at 10.1.1.110/24
- **Minimal main config**: Only imports and core settings in configuration.nix
- **Packages**: ONLY use `modules/system-packages.nix` for system packages
- **Services**: Create dedicated modules, don't add to main config
- **Users**: ALL user settings in `modules/users.nix` (accounts, groups, sudo, shell)
- **Distributed builds**: 51 cores across zephyr (32), nexus (8), forge (3), sentry (8)

## ANTI-PATTERNS (THIS PROJECT)
- **NEVER edit** `hardware-configuration.nix` (auto-generated, line 1-3)
- **NEVER** duplicate packages - use `modules/system-packages.nix` only
- **NEVER** add services to main config - use dedicated modules
- **NEVER** make edits without reading the entire file first - always read completely before editing
- **NEVER** add user settings to main config - use `modules/users.nix`
- **NEVER USE WORKAROUNDS** - Always fix root causes directly, never disable features or find temporary hacks
- **PermitRootLogin = "yes"** in SSH config (security risk, line 240)
- **Passwordless sudo** for wheel group (security risk, line 58 in users.nix)

## UNIQUE STYLES
- User `j_kro` has passwordless sudo (wheel group)
- Auto-login enabled for `j_kro` user (plasma session, line 89-92)
- Hostname: "zephyr"
- Btrfs subvolumes: @, @home, /data
- **Custom mining option**: `services.mining` (not in upstream)
- **Smart mining pause**: Auto-detects VR (WiVRn/SteamVR), games, high GPU (>70%)
- **VRChat analytics blocked**: 18+ domains via extraHosts
- **WiVRn for Quest Pro**: 100Mbps HEVC streaming, spatial/temporal encoding, RTX 3090 optimizations
- **GameMode NVIDIA overclock**: +150MHz, maximum performance mode
- **systemd slices**: vr.slice, gaming.slice for priority scheduling
- **Custom packages**: lolminer/xmrig with steam-run wrapper pattern
- **Multi-tier DNS**: Local Unbound (port 53) → DoT to Google/Cloudflare/Quad9 (port 853)
- **Zen Browser**: Dynamic key fetching from GitHub, forced extensions via policies
- **Mining health monitoring**: 5-minute timer checks API, restarts if hashrate=0
- **Distributed builds**: 51-core cluster with `--builders-use-substitutes`
- **KDE Plasma fixes**: xdg-desktop-portal-kde, Wayland environment, NVIDIA modesetting

## COMMANDS
| ## OPENAGENTS CONTROL

| Usage Guide | OpenAgents Control is installed via NixOS module and provides the following commands:

### Installation
```bash
# Enable OpenAgents Control in configuration.nix
services.openagents-control.enable = true;

# Select installation profile (optional, defaults to "developer")
services.openagents-control.installProfile = "advanced"; # essential | developer | business | full | advanced

# Apply changes
sudo nixos-rebuild switch --flake .
```

### Commands
```bash
# Install OpenAgents Control with selected profile
opencode-install

# Update existing installation
opencode-update

# Enable OpenCode wrapper (after installation)
openable-enable

# Use OpenCode agents (after enabling)
opencode --agent openagent     # Universal agent for general tasks
opencode --agent opencoder     # Development specialist for complex coding
```

### Features
- **Plan-first workflow** - Agents propose plans before implementing
- **Multi-language support** - Works with TypeScript, Python, Go, Rust, and more
- **Automatic testing** - Built-in code review and validation
- **Context-aware** - Agents follow your coding patterns from configuration files

- **System Builder** - Advanced profile includes interactive tool for creating custom AI systems

### Configuration
- **Installation directory**: `services.openagents-control.installDir` (default: `~/.config/opencode`)
- **Profile selection**: Essential (9 components), Developer (30 components), Business (15 components), Full (36 components), Advanced (43 components)
- **Auto-update**: Enable daily automatic component updates via `services.openagents-control.autoUpdate`

### Integration
OpenAgents Control integrates with OpenCode CLI (`opencode` command) to provide:
- Main agents: openagent, opencoder, system-builder
- Specialized subagents: task-manager, coder-agent, reviewer, tester, build-agent, etc.
- Custom commands: /commit, /optimize, /test, /clean, /context, etc.
- Context files: Essential patterns and project-specific coding standards

| ## COMMANDS
```bash
# Enter dev shell (if defined)
nix develop

# Rebuild system
sudo nixos-rebuild switch --flake .

# Update flake inputs
nix flake update

# Check configuration
nix flake check

# Build system (dry run)
sudo nixos-rebuild build --flake .

# Test configuration
sudo nixos-rebuild test --flake .

# User shell aliases (home.nix:108-110)
update  # sudo nixos-rebuild switch --flake /etc/nixos
build   # sudo nixos-rebuild build --flake /etc/nixos
test    # sudo nixos-rebuild test --flake /etc/nixos

# Distributed builds
nix build --builders-use-substitutes nixpkgs#package-name

# Cluster management
just cluster-info
just cluster-resources
just cluster-status
```

## NOTES
- **This is a personal config**, not a library
- **Modular architecture**: features in `modules/`, custom pkgs in `packages/`
- **Channel**: nixos-unstable
- **Mining services** auto-pause when VR/gaming detected (via mining-smart-pause service)
- **WiVRn configured** for Quest Pro with RTX 3090 optimizations (LVRA-compliant)
- **VRChat analytics** blocked in /etc/hosts (privacy)
- **AAGL launchers** enabled directly in config (Genshin, Star Rail, Zenless) - module import disabled
- **Home Manager**: user j_kro config with Zen Browser, Git/Neovim/Bash, Vesktop autostart
- **Nixcord**: Disabled due to plugin compatibility (line 50 in flake.nix, line 159 in home.nix)
- **Flatpak**: Disabled due to cache issues (lines 175-186 in configuration.nix)
- **Shell scripts**: fix-zen-key.sh, simple-rebuild.sh, update-zen-flake.sh (broken) at root
- **Clawdbot Enhancement**: 12-week roadmap to enhance basic Clawdbot with advanced features
- **Multi-Agent Patterns**: Leveraging AstralDev's specialized agents for code generation and review
- **RAG Integration**: Planning PostgreSQL + Qdrant + Redis for semantic search
- **OpenCode/MCP Integration**: Planning AI-RAG-MCP patterns for development workflows
- **Real-Time Communication**: Planning WebSocket patterns for multi-platform support
- **Distributed Build System**: 51-core cluster with automatic load balancing and builder substitution


### Current Status

### Enhancement Goals
1. **Multi-Agent Architecture** - Leverage AstralDev's specialized agents
2. **RAG Knowledge Base** - Implement semantic search with vector databases
3. **OpenCode/MCP Integration** - Add AI-RAG-MCP development workflows
4. **Real-Time Communication** - Adapt WebSocket patterns for multi-platform support
5. **Zero-Cost AI Models** - Route to free model providers

### Integration Projects
| Project | Patterns Used | Integration Path |
|---------|----------------|------------------|
| **AstralDev** | Specialized agents, AgentPool, MainOrchestrator | Multi-agent coordination for code tasks |
| **PolyBot** | WebSocket server, message routing, alert system | Real-time chat and notifications |
| **MindFrame** | RAG with PostgreSQL+Qdrant+Redis, code ingestion | Knowledge base and semantic search |
| **AI-RAG-MCP** | MCP server, free model routing, OpenCode integration | Development workflow enhancement |

### Key Features to Implement
- [x] Roadmap document (12-week plan)
- [x] Implementation plan (detailed tasks)
- [ ] Configure Telegram bot integration
- [ ] Add RAG knowledge base with Qdrant
- [ ] Implement multi-agent system
- [ ] Add OpenCode/MCP integration
- [ ] Create WebSocket real-time server
- [ ] Add free AI model routing
- [ ] Deploy with NixOS systemd services

### Documentation
- **Integration Guides**: (to be created)
- **API Documentation**: (to be created)

## SECURITY AUDIT RESULTS

### ✅ Issues Resolved
1. **Hardcoded API Key** - Removed from `home.nix:190`, now uses agenix secrets
2. **Mining API Ports** - Restricted to localhost via firewall rules
3. **Wallet Addresses** - Made configurable via `walletSecret` option
4. **Code Duplication** - Eliminated 184 lines through modularization
5. **KDE Plasma Window Management** - Fixed with proper environment and packages

### 🔒 Security Configuration
- **Nix builders**: 51-core distributed build pool configured
- **SSH**: Key-only authentication with trusted users
- **Firewall**: Minimal ports, VR-specific allowances
- **Binary caches**: Multiple trusted substituters
- **User privileges**: Limited trusted users for build operations

## DISTRIBUTED BUILD SYSTEM

 ### ✅ Active Configuration
 - **Total Capacity**: 51 cores across cluster
 - **Configuration**: `builders = "root@zephyr /nix/store - - 32 root@nexus /nix/store - - 8 root@forge /nix/store - - 3 root@sentry /nix/store - - 8"`
 - **Usage**: `nix build --builders-use-substitutes nixpkgs#package-name`
 - **Colmena**: Multi-host deployment configured in `colmena.nix`

### 📊 Performance
- **zephyr**: 32 cores (master)
- **nexus**: 8 cores (build node)
- **forge**: 3 cores (build node)
- **sentry**: 8 cores (build node)
- **Usage**: Automatic load balancing across all nodes

## KDE PLASMA WINDOW MANAGEMENT

### ✅ Fixes Applied
1. **Missing xdg-desktop-portal-kde** - Added to system packages
2. **Environment Variables** - QT_QPA_PLATFORM, GDK_BACKEND, XDG_SESSION_TYPE
3. **NVIDIA Modesetting** - Enabled for Plasma stability
4. **SDDM Wayland** - Enabled for proper session management
5. **Essential KDE Packages** - kdbusaddons, kdeconnect, systemmonitor

### 🎮 Ready to Use
```bash
# Optional fix script (already configured)
sudo /etc/nixos/fix-plasma.sh

# Log out and log back in for Wayland session
# Verify: echo $QT_QPA_PLATFORM should output 'wayland'
```

## FACTORY.AI INTEGRATION

### Current Status
- **Platform**: Factory.ai - Agent-Native Software Development
- **License**: Commercial (not open source)
- **Pricing**: Free tier available, Pro $20/month, Max $200/month
- **GitHub**: Public repository (462 stars, 34 forks) - https://github.com/factory-ai/factory

### Integration Potential
Factory.ai offers several features that align with the Clawdbot enhancement roadmap:

1. **Agent-Native Development** - "Droids" that work across CLI, Web, Slack, IDE
2. **Model-Agnostic** - Supports OpenAI, Anthropic, Google, X AI, open-source, local models
3. **Context-Confidence** - Incremental compression with anchor points
4. **Enterprise Features** - SSO/SAML, dedicated compute, compliance & security
5. **MCP Support** - Model Context Protocol for external tool integration

### Pricing Structure
- **Free**: BYOK (Bring Your Own Key) - $0/month
- **Pro**: 10M tokens + 10M bonus - $20/month
- **Max**: 100M tokens + 100M bonus - $200/month
- **Ultra**: 1B tokens + 1B bonus - $2,000/month

### Model Multipliers
- Droid Core (glm-4.6): 0.25×
- Claude Haiku 4.5: 0.4×
- GPT-5.1: 0.5×
- GPT-5.2: 0.7×
- Claude Sonnet 4.5: 1.2×
- Claude Opus 4.5: 2×

### Quick Start
```bash
# Install Factory CLI
curl -fsSL https://app.factory.ai/cli | sh

# Start in NixOS project
cd /etc/nixos
droid

# Example commands for NixOS management
> analyze this NixOS configuration and suggest optimizations
> audit this codebase for security vulnerabilities
> implement the feature described in this GitHub issue
```

### Integration Opportunities
1. **Replace/Enhance Clawdbot** - Use Factory's Droids as the underlying agent platform
2. **NixOS Configuration Management** - Leverage for complex refactors and migrations
3. **Distributed Build System** - Use for CI/CD automation and build optimization
4. **Security Auditing** - Automated vulnerability scanning and remediation
5. **Documentation Generation** - Auto-generate and maintain AGENTS.md

### Considerations
- **Commercial Product**: Not open source, requires subscription for full features
- **Vendor Lock-in**: Dependent on Factory.ai platform and infrastructure
- **Privacy**: Code processed through external service (self-hosting options unclear)
- **Complexity**: May be overkill for current Clawdbot use case

### Recommendation
Consider Factory.ai for:
- Complex NixOS configuration management tasks
- Security auditing and compliance
- Large-scale refactoring projects
- Team collaboration workflows

For simple Clawdbot enhancements, continue with open source solutions first.