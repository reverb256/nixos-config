#!/usr/bin/env fish

# Demo script for Smart Fish Shell with Project Detection
# This script demonstrates the smart project detection capabilities

echo "🎯 Smart Fish Shell Demo"
echo "========================"
echo ""

# Function to test project detection
function test_project
    set project_dir $argv[1]
    set project_name $argv[2]
    
    echo "📍 Testing $project_name project:"
    echo "   Directory: $project_dir"
    
    if test -d $project_dir
        cd $project_dir
        
        # Simulate project detection (in real Fish, this happens automatically)
        set project_type (_smart_get_project_type 2>/dev/null; or echo "unknown")
        set project_context (_smart_get_project_context $project_type 2>/dev/null; or echo "Unknown project")
        
        echo "   🏷️  Type: $project_type"
        echo "   📝 Context: $project_context"
        
        # Show available aliases
        echo "   🛠️  Available aliases: dev, test, build, run"
        
        cd ..
    else
        echo "   ❌ Directory not found: $project_dir"
    end
    
    echo ""
end

# Test each project type
echo "Testing Smart Project Detection..."
echo ""

test_project "test-projects/nextjs-app" "Next.js"
test_project "test-projects/rust-project" "Rust"
test_project "test-projects/python-project" "Python"
test_project "test-projects/nixos-module" "NixOS Module"
test_project "test-projects/solana-project" "Solana/Anchor"

echo "🎮 Demo Complete!"
echo ""
echo "💡 To experience this in real-time:"
echo "   cd test-projects/nextjs-app"
echo "   fish --init-command 'echo \"Fish will auto-detect this as Next.js project\"'"
echo ""
echo "🚀 Your shell environment now adapts intelligently to your projects!"