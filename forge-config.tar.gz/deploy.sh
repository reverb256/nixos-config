#!/bin/bash

# Deployment Execution Script: Master to Shell-Dev Merge
# This script automates the deployment process described in DEPLOYMENT_PLAN.md

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="/var/log/deployment.log"
BACKUP_DIR="/etc/nixos.backup.$(date +%Y%m%d_%H%M%S)"
STAGE=""

# Logging function
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Error handling
error_exit() {
    log "ERROR: $1"
    log "Rolling back deployment..."
    rollback
    exit 1
}

# Function to check prerequisites
check_prerequisites() {
    log "Checking prerequisites..."
    
    # Check if running as root
    if [[ $EUID -ne 0 ]]; then
        error_exit "This script must be run as root (use sudo)"
    fi
    
    # Check if git repository
    if ! git rev-parse --git-dir > /dev/null 2>&1; then
        error_exit "Not in a git repository"
    fi
    
    # Check if nix is available
    if ! command -v nix &> /dev/null; then
        error_exit "Nix is not installed or not in PATH"
    fi
    
    # Check if flake.nix exists
    if [[ ! -f "$SCRIPT_DIR/flake.nix" ]]; then
        error_exit "flake.nix not found in $SCRIPT_DIR"
    fi
    
    log "Prerequisites check passed"
}

# Function to create backup
create_backup() {
    log "Creating backup..."
    mkdir -p "$BACKUP_DIR"
    cp -r "$SCRIPT_DIR"/* "$BACKUP_DIR/" 2>/dev/null || true
    git stash push -m "Pre-deployment backup $(date)"
    log "Backup created at $BACKUP_DIR"
}

# Function to validate configuration
validate_configuration() {
    log "Validating Nix configuration..."
    
    if ! nix flake check --flake "$SCRIPT_DIR" 2>&1 | tee -a "$LOG_FILE"; then
        error_exit "Nix flake validation failed"
    fi
    
    if ! nix eval --flake "$SCRIPT_DIR#nixosConfigurations.zephyr.config" &>/dev/null; then
        error_exit "NixOS configuration evaluation failed"
    fi
    
    log "Configuration validation passed"
}

# Function to merge shell-dev
merge_shell_dev() {
    log "Merging shell-dev content..."
    
    if [[ ! -d "$SCRIPT_DIR/shell-dev" ]]; then
        error_exit "shell-dev directory not found"
    fi
    
    # Add shell-dev to git
    git add shell-dev/ 2>&1 | tee -a "$LOG_FILE"
    
    # Create merge commit
    git commit -m "feat: merge AI agent optimized Fish shell implementation from shell-dev" 2>&1 | tee -a "$LOG_FILE"
    
    log "Shell-dev merge completed"
}

# Function to build VM configuration
build_vm() {
    log "Building VM configuration..."
    
    if ! nixos-rebuild build --flake "$SCRIPT_DIR" --target-host localhost 2>&1 | tee -a "$LOG_FILE"; then
        error_exit "VM build failed"
    fi
    
    log "VM build completed successfully"
}

# Function to test Fish shell functionality
test_fish_shell() {
    log "Testing Fish shell functionality..."
    
    # Test Fish shell basic functionality
    if ! fish --version &>/dev/null; then
        error_exit "Fish shell is not available"
    fi
    
    # Test smart project detection
    cd "$SCRIPT_DIR/shell-dev/test-projects/nextjs-app" 2>/dev/null || true
    if ! fish -c "echo \$SMART_PROJECT_CONTEXT" | grep -q "Next.js"; then
        log "Warning: Next.js project detection may not be working"
    fi
    
    # Test dynamic aliases
    if ! fish -c "which dev" &>/dev/null; then
        log "Warning: Dynamic aliases may not be working"
    fi
    
    log "Fish shell testing completed"
}

# Function to deploy to production
deploy_production() {
    log "Deploying to production..."
    
    # Test deployment first
    log "Testing deployment configuration..."
    if ! nixos-rebuild test --flake "$SCRIPT_DIR" 2>&1 | tee -a "$LOG_FILE"; then
        error_exit "Deployment test failed"
    fi
    
    # Perform actual deployment
    log "Switching to new configuration..."
    if ! nixos-rebuild switch --flake "$SCRIPT_DIR" 2>&1 | tee -a "$LOG_FILE"; then
        error_exit "Production deployment failed"
    fi
    
    log "Production deployment completed"
}

# Function to validate deployment
validate_deployment() {
    log "Validating deployment..."
    
    # Check system status
    if ! systemctl is-active --quiet systemd-user-sessions; then
        error_exit "System services are not running properly"
    fi
    
    # Test Fish shell as user
    if ! sudo -u j_kro fish -c "echo 'Deployment successful'" &>/dev/null; then
        error_exit "User Fish shell is not working"
    fi
    
    # Test project detection
    if ! sudo -u j_kro fish -c "echo \$SMART_PROJECT_CONTEXT" &>/dev/null; then
        log "Warning: Project detection may not be working for user"
    fi
    
    log "Deployment validation completed"
}

# Function to rollback deployment
rollback() {
    log "Performing rollback..."
    
    # Rollback git changes
    git reset --hard HEAD~1 2>&1 | tee -a "$LOG_FILE"
    
    # Rollback NixOS configuration
    nixos-rebuild switch --rollback 2>&1 | tee -a "$LOG_FILE"
    
    # Restore backup if available
    if [[ -d "$BACKUP_DIR" ]]; then
        cp -r "$BACKUP_DIR"/* "$SCRIPT_DIR/" 2>/dev/null || true
    fi
    
    log "Rollback completed"
}

# Function to cleanup
cleanup() {
    log "Cleaning up temporary files..."
    log "Cleanup completed"
}

# Function to show deployment summary
show_summary() {
    log "=== DEPLOYMENT SUMMARY ==="
    log "Backup location: $BACKUP_DIR"
    log "Log file: $LOG_FILE"
    log "Deployment completed successfully"
    log "Next steps:"
    log "  1. Monitor system for 24 hours"
    log "  2. Test user workflows"
    log "  3. Validate performance metrics"
    log "  4. Update documentation if needed"
}

# Main deployment function
main() {
    log "Starting deployment process..."
    log "Deployment plan: Master to Shell-Dev Merge"
    log "Target: AI agent optimized Fish shell implementation"
    
    # Execute deployment stages
    check_prerequisites
    create_backup
    validate_configuration
    merge_shell_dev
    build_vm
    test_fish_shell
    deploy_production
    validate_deployment
    cleanup
    show_summary
    
    log "Deployment completed successfully!"
}

# Handle command line arguments
case "${1:-}" in
    --rollback)
        rollback
        ;;
    --test)
        check_prerequisites
        validate_configuration
        test_fish_shell
        ;;
    *)
        main
        ;;
esac