{
  inputs = {
    nixpkgs.url = "github:nixos/nixpkgs/nixos-unstable";
    nixpkgs-xr.url = "github:nix-community/nixpkgs-xr";
    nixpkgs-xr.inputs.nixpkgs.follows = "nixpkgs";

    # Home Manager
    home-manager.url = "github:nix-community/home-manager";
    home-manager.inputs.nixpkgs.follows = "nixpkgs";

    # Zen Browser Flake
    zen-browser.url = "github:0xc000022070/zen-browser-flake";
    zen-browser.inputs.nixpkgs.follows = "nixpkgs";
    zen-browser.inputs.home-manager.follows = "home-manager";

    # Anime Games Launcher (ezKEa)
    ezkea.url = "github:ezKEa/aagl-gtk-on-nix";

    # Nixcord - Declarative Discord/Vesktop configuration
    nixcord.url = "github:FlameFlag/nixcord";

    # Enhanced Gaming Packages (Proton-GE, GameMode, etc.)
    nix-gaming.url = "github:fufexan/nix-gaming";

    # Claude Code Native Binary
    claude-native.url = "github:ryoppippi/claude-code-overlay";
    claude-native.inputs.nixpkgs.follows = "nixpkgs";

    # Agenix - Age-encrypted secrets for NixOS
    agenix.url = "github:ryantm/agenix";
    agenix.inputs.nixpkgs.follows = "nixpkgs";
    nix-gaming.inputs.nixpkgs.follows = "nixpkgs";

    # Determinate Nix module
    determinate.url = "https://flakehub.com/f/DeterminateSystems/determinate/*";

    # OpenCode AI Agent
    opencode.url = "github:anomalyco/opencode/dev";

    # Colmena - Multi-host deployment
    colmena.url = "github:zhaofengli/colmena/v0.4.0";
    colmena.inputs.nixpkgs.follows = "nixpkgs";
  };

  outputs = inputs @ {
    self,
    nixpkgs,
    zen-browser,
    ezkea,
    home-manager,
    nixcord,
    nix-gaming,
    determinate,
    claude-native,
    opencode,
    agenix,
    colmena,
    ...
  }: {
    # Shared overlays
    overlays = {
      mining-overlay = import ./modules/mining-overlay.nix;
    };

    # Colmena configuration
    colmena = {
      meta = {
        nixpkgs = import inputs.nixpkgs {
          system = "x86_64-linux";
          config.allowUnfree = true;
          overlays = [
            (final: prev: {
              mining-overlay = import ./modules/mining-overlay.nix;
            })
          ];
        };
      };
      nodes = import ./hosts;
    };

    # Zephyr - Master Workstation (VR Gaming + Development)
    nixosConfigurations.zephyr = nixpkgs.lib.nixosSystem {
      system = "x86_64-linux";
      specialArgs = {inherit self inputs claude-native ezkea opencode; opencode-patched = self.packages.x86_64-linux.opencode;};
      modules = [
        ./configuration.nix
        ./hardware-configuration.nix
        {
          networking.hostName = "zephyr";
          nixpkgs.overlays = [
            inputs.self.overlays.mining-overlay
            (inputs.claude-native.overlay or (_: _: {}))
          ];

          # Anime game launchers (workstation only)
          programs.anime-game-launcher.enable = true;
          programs.honkers-railway-launcher.enable = true;
          programs.sleepy-launcher.enable = true;

          # Proton-GE-RTSP - Enhanced Proton with RTSP video support for VRChat
          programs.steam.extraCompatPackages = [
            inputs.nixpkgs-xr.packages.x86_64-linux.proton-ge-rtsp-bin
          ];
        }
        ezkea.nixosModules.default
        agenix.nixosModules.default
        home-manager.nixosModules.home-manager
        {
          home-manager.useGlobalPkgs = true;
          home-manager.useUserPackages = true;
          home-manager.backupFileExtension = "backup";
          home-manager.extraSpecialArgs = {inherit inputs;};
          home-manager.users.j_kro = {
            imports = [./home.nix];
          };
        }
      ];
    };

    # Nexus - Build Server
    nixosConfigurations.nexus = nixpkgs.lib.nixosSystem {
      system = "x86_64-linux";
      specialArgs = {inherit self inputs claude-native ezkea opencode; opencode-patched = self.packages.x86_64-linux.opencode;};
      modules = [
        ./configuration.nix
        ./hosts/nexus/hardware-configuration.nix
        {
          networking.hostName = "nexus";
          nixpkgs.overlays = [
            inputs.self.overlays.mining-overlay
            (inputs.claude-native.overlay or (_: _: {}))
          ];
        }
        ezkea.nixosModules.default
        agenix.nixosModules.default
        home-manager.nixosModules.home-manager
        {
          home-manager.useGlobalPkgs = true;
          home-manager.useUserPackages = true;
          home-manager.backupFileExtension = "backup";
          home-manager.extraSpecialArgs = {inherit inputs;};
          home-manager.users.j_kro = {
            imports = [./home.nix];
          };
        }
      ];
    };

    # Forge - GPU Compute Cluster Node
    nixosConfigurations.forge = nixpkgs.lib.nixosSystem {
      system = "x86_64-linux";
      specialArgs = {inherit self inputs claude-native ezkea opencode; opencode-patched = self.packages.x86_64-linux.opencode;};
      modules = [
        ./configuration.nix
        ./hosts/forge/hardware-configuration.nix
        {
          networking.hostName = "forge";
          nixpkgs.overlays = [
            inputs.self.overlays.mining-overlay
            (inputs.claude-native.overlay or (_: _: {}))
          ];
        }
        ezkea.nixosModules.default
        agenix.nixosModules.default
        home-manager.nixosModules.home-manager
        {
          home-manager.useGlobalPkgs = true;
          home-manager.useUserPackages = true;
          home-manager.backupFileExtension = "backup";
          home-manager.extraSpecialArgs = {inherit inputs;};
          home-manager.users.j_kro = {
            imports = [./home.nix];
          };
        }
      ];
    };

    # Sentry - Monitoring Node
    nixosConfigurations.sentry = nixpkgs.lib.nixosSystem {
      system = "x86_64-linux";
      specialArgs = {inherit self inputs claude-native ezkea opencode; opencode-patched = self.packages.x86_64-linux.opencode;};
      modules = [
        ./configuration.nix
        ./hosts/sentry/hardware-configuration.nix
        {
          networking.hostName = "sentry";
          nixpkgs.overlays = [
            inputs.self.overlays.mining-overlay
            (inputs.claude-native.overlay or (_: _: {}))
          ];
        }
        ezkea.nixosModules.default
        agenix.nixosModules.default
        home-manager.nixosModules.home-manager
        {
          home-manager.useGlobalPkgs = true;
          home-manager.useUserPackages = true;
          home-manager.backupFileExtension = "backup";
          home-manager.extraSpecialArgs = {inherit inputs;};
          home-manager.users.j_kro = {
            imports = [./home.nix];
          };
        }
      ];
    };
  };
}
