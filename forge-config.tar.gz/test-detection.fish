#!/usr/bin/env fish

# Simple test script for Fish project detection
# This bypasses Home Manager to test the logic directly

# Project detection functions (simplified version)
function _smart_get_project_type
    # NixOS/System Configuration
    if test -f flake.nix -o -f configuration.nix -o -f default.nix
        if string match -q "*/etc/nixos*" -- $PWD
            echo "nixos-config"
        else if test -f flake.nix
            echo "nix-flake"
        else
            echo "nix-package"
        end
        return
    end

    # Web Development
    if test -f package.json
        if test -f next.config.js -o -f next.config.ts -o -f next.config.mjs
            echo "nextjs"
        else if test -f nuxt.config.js -o -f nuxt.config.ts
            echo "nuxt"
        else if test -f svelte.config.js -o -f svelte.config.ts
            echo "svelte"
        else if test -f vite.config.js -o -f vite.config.ts -o -f vite.config.mjs
            echo "vite"
        else
            echo "nodejs"
        end
        return
    end

    # Python Development
    if test -f requirements.txt -o -f pyproject.toml -o -f setup.py -o -f Pipfile
        if test -f manage.py -o -f wsgi.py
            echo "django"
        else if test -f app.py -o test -f main.py -a -f requirements.txt
            echo "flask"
        else if test -f pytest.ini -o -f tox.ini -o -d tests/
            echo "python"
        else
            echo "python"
        end
        return
    end

    # Rust Development
    if test -f Cargo.toml
        echo "rust"
        return
    end

    # Go Development
    if test -f go.mod -o -f main.go
        echo "golang"
        return
    end

    # Default
    echo "generic"
end

function _smart_get_project_context
    set -l project_type $argv[1]
    switch $project_type
        case nixos-config
            echo "⚒️ NixOS System Configuration"
        case nix-flake
            echo "🔧 Nix Flake Project"
        case nix-package
            echo "📦 Nix Package Development"
        case nextjs
            echo "⚛️ Next.js Web Application"
        case nuxt
            echo "🟢 Nuxt.js Web Application"
        case svelte
            echo "🔥 SvelteKit Application"
        case vite
            echo "⚡ Vite-based Application"
        case nodejs
            echo "📦 Node.js Project"
        case django
            echo "🎸 Django Web Framework"
        case flask
            echo "🧪 Flask Web Framework"
        case python
            echo "🐍 Python Project"
        case rust
            echo "🦀 Rust Application"
        case golang
            echo "🐹 Go Application"
        case '*'
            echo "📁 Generic Project"
    end
end

# Test function
function test_project_detection
    set project_dir $argv[1]
    set project_name $argv[2]
    
    echo "📍 Testing $project_name project:"
    echo "   Directory: $project_dir"
    
    if test -d $project_dir
        cd $project_dir
        
        # Run project detection
        set project_type (_smart_get_project_type)
        set project_context (_smart_get_project_context $project_type)
        
        echo "   🏷️  Type: $project_type"
        echo "   📝 Context: $project_context"
        
        # Test specific detection
        if test $project_type = "nextjs"
            echo "   ✅ Correctly detected as Next.js"
        else if test $project_type = "rust"
            echo "   ✅ Correctly detected as Rust"
        else if test $project_type = "python"
            echo "   ✅ Correctly detected as Python"
        else if test $project_type = "nix-package"
            echo "   ✅ Correctly detected as Nix package"
        else
            echo "   ❌ Unexpected project type"
        end
        
        cd ..
    else
        echo "   ❌ Directory not found: $project_dir"
    end
    
    echo ""
end

# Run tests
echo "🎯 Smart Fish Shell Project Detection Test"
echo "=========================================="
echo ""

test_project_detection "test-projects/nextjs-app" "Next.js"
test_project_detection "test-projects/rust-project" "Rust"
test_project_detection "test-projects/python-project" "Python"
test_project_detection "test-projects/nixos-module" "NixOS Module"

echo "🎮 Test Complete!"
echo ""
echo "💡 The actual Fish implementation will:"
echo "   - Run these functions automatically on directory change"
echo "   - Set environment variables: SMART_PROJECT_TYPE, SMART_PROJECT_CONTEXT"
echo "   - Update aliases based on project type"
echo "   - Update Starship prompt with project information"