{
  zephyr = {
    deployment = {
      targetHost = "10.1.1.110";
      targetUser = "j_kro";
    };
    imports = [ ./configuration.nix ./hardware-configuration.nix ];
    networking.hostName = "zephyr";
    nixpkgs.overlays = [
      (final: prev: {
        mining-overlay = import ./modules/mining-overlay.nix;
      })
    ];
    programs.anime-game-launcher.enable = true;
    programs.honkers-railway-launcher.enable = true;
    programs.sleepy-launcher.enable = true;
    
  };
  
  nexus = {
    deployment = {
      targetHost = "10.1.1.120";
      targetUser = "j_kro";
    };
    imports = [ ./configuration.nix ./hosts/nexus/hardware-configuration.nix ];
    networking.hostName = "nexus";
  };
  
  forge = {
    deployment = {
      targetHost = "10.1.1.130";
      targetUser = "j_kro";
    };
    imports = [ ./configuration.nix ./hosts/forge/hardware-configuration.nix ];
    networking.hostName = "forge";
    
    # Forge mining configuration (GPU compute rig)
    services.mining.enable = true;
    services.mining.xmrig.enable = false;  # Disable CPU mining on forge
    services.mining.lolminer.enable = true;  # GPU mining only

    services.mining.lolminer.algorithm = "CR29";
    services.mining.lolminer.pool = "stratum+ssl://xtm-c29-us.kryptex.network:8040";
    services.mining.lolminer.wallet = "krxXVNVMM7.forge";
    
    # NVIDIA GPUs (RTX 4060s)
    services.mining.lolminer.nvidia.enable = true;
    services.mining.lolminer.nvidia.devices = "0,1";  # Both RTX 4060s
    services.mining.lolminer.nvidia.powerLimit = 90;  # RTX 4060 power limit
    services.mining.lolminer.nvidia.apiPort = 4068;
    
    # AMD GPUs (RX 5700 XTs)
    services.mining.lolminer.amd.enable = true;
    services.mining.lolminer.amd.devices = "2,3";  # Both RX 5700 XTs
    services.mining.lolminer.amd.powerLimit = 140;  # RX 5700 XT power limit
    services.mining.lolminer.amd.apiPort = 4069;

    # Enable both AMD and NVIDIA drivers
    hardware.amdgpu.opencl.enable = true;
    hardware.opengl.enable = true;
    services.xserver.videoDrivers = [ "amdgpu" "nvidia" ];
  };
  
  sentry = {
    deployment = {
      targetHost = "10.1.1.140";
      targetUser = "j_kro";
    };
    imports = [ ./configuration.nix ./hosts/sentry/hardware-configuration.nix ];
    networking.hostName = "sentry";
  };
}