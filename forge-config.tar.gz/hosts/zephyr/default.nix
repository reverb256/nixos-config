# Zephyr Host-Specific Configuration
# 10.1.1.110 - Master Workstation (32 cores, RTX 3090)
{ lib, ... }:

{
  imports = [
    # Host-specific networking (static IP, VR firewall ports)
    # NOTE: ./default.nix would be circular - removed
  ];

  # ============================================================================
  # HARDWARE CONFIGURATION (Inline for Colmena compatibility)
  # ============================================================================

  boot.initrd.availableKernelModules = ["nvme" "xhci_pci" "ahci" "usbhid" "usb_storage" "sd_mod"];
  boot.initrd.kernelModules = [];
  boot.kernelModules = ["kvm-amd"];
  boot.extraModulePackages = [];

  fileSystems."/" = {
    device = "/dev/disk/by-uuid/ef478ffa-ab37-475e-8304-06767d9161a3";
    fsType = "btrfs";
    options = ["subvol=@"];
  };

  fileSystems."/home" = {
    device = "/dev/disk/by-uuid/ef478ffa-ab37-475e-8304-06767d9161a3";
    fsType = "btrfs";
    options = ["subvol=@home"];
  };

  fileSystems."/boot" = {
    device = "/dev/disk/by-uuid/EB7C-E7CC";
    fsType = "vfat";
    options = ["fmask=0077" "dmask=0077"];
  };

  fileSystems."/data" = {
    device = "/dev/disk/by-uuid/4c249712-3c96-44dd-bab0-0b077a168670";
    fsType = "btrfs";
    options = ["subvol=data"];
  };

  swapDevices = [
    {device = "/dev/disk/by-uuid/e41f2f97-013a-4c2c-8eb2-7214768fcf4d";}
    {device = "/dev/disk/by-uuid/f1fa3b38-f788-485b-8e56-58ecbe526091";}
  ];

  # ============================================================================
  # BOOTLOADER - systemd-boot
  # ============================================================================

  boot.loader = {
    systemd-boot.enable = true;
    efi.canTouchEfiVariables = true;
  };

  # ============================================================================
  # HIGH-PERFORMANCE KERNEL PARAMETERS (from master branch)
  # ============================================================================

  boot.kernelParams = [
    # Wine gaming performance
    "fsync.enable=1"

    # NVIDIA optimizations (desktop.nix adds nvidia-drm.modeset=1)
    "nvidia-drm.modeset=1"
    "threadirqs"

    # Ryzen 5950X optimizations
    "amd_pstate=active"
    "mitigations=off"
    "transparent_hugepage=madvise"
    "numa_balancing=disable"
    "nowatchdog"

    # PCIe and I/O optimizations
    "pcie_aspm=off"
    "elevator=none"

    # High-priority gaming optimizations
    "isolcpus=managed_applications" # CPU isolation for gaming
    "nohz_full=1-15" # Disable tick on application cores
    "rcu_nocbs=1-15" # RCU offload for low latency
  ];

  # ============================================================================
  # SYSCTL OPTIMIZATIONS (from master branch)
  # ============================================================================

  boot.kernel.sysctl = {
    # Network optimizations for gaming
    "net.core.rmem_max" = 2500000;
    "net.core.wmem_max" = 2500000;

    # Memory management
    "vm.swappiness" = 10;
    "vm.vfs_cache_pressure" = 50;

    # CPU scheduler optimizations
    "kernel.sched_min_granularity_ns" = 10000000;
    "kernel.sched_wakeup_granularity_ns" = 15000000;
    "kernel.sched_migration_cost_ns" = 500000;

    # High-priority gaming sysctl optimizations
    "kernel.sched_autogroup_enabled" = 0; # Disable autogroups for lower latency
    "kernel.sched_child_runs_first" = 0; # Allow parent to run first
    "kernel.sched_ttwu_protect" = 1; # Protect wakeups
    "kernel.sched_min_runtime" = 5000000; # Minimum runtime per slice
    "vm.dirty_ratio" = 5; # Reduce dirty page ratio
    "vm.dirty_background_ratio" = 2; # Reduce dirty background ratio
    "vm.dirty_expire_centisecs" = 100; # Faster dirty page expiration
    "vm.dirty_writeback_centisecs" = 50; # Faster writeback
    "kernel.timer_migration" = 1; # Allow timer migration
    "kernel.perf_event_paranoid" = -1; # Allow perf monitoring
  };

  # ============================================================================
  # HOSTNAME
  # ============================================================================

  networking.hostName = "zephyr";

  # ============================================================================
  # NETWORKING (Static IP)
  # ============================================================================

  # Configure NetworkManager for ethernet with static IP
  networking.networkmanager.ensureProfiles = {
    profiles."Wired connection 1" = {
      connection = {
        id = "Wired connection 1";
        type = "ethernet";
        interface-name = "enp38s0";
        autoconnect = true;
      };
      ipv4 = {
        method = "manual";
        address1 = "10.1.1.110/24";
        gateway = "10.1.1.1";
        dns = "127.0.0.1,::1";
      };
      ipv6 = {
        method = "auto";
      };
    };
  };

  # ============================================================================
  # LOCAL HOSTS ENTRIES
  # ============================================================================

  networking.hosts = {
    "10.1.1.110" = ["zephyr"];
    "10.1.1.120" = ["nexus"];
    "10.1.1.130" = ["forge"];
    "10.1.1.140" = ["sentry"];
  };

  # ============================================================================
  # FIREWALL (VR ports for WiVRn streaming)
  # ============================================================================

  networking.firewall = {
    allowedTCPPorts = [9757]; # WiVRn TCP
    allowedUDPPorts = [
      9757 # WiVRn UDP
      9758 # WiVRn control
      9759 # Lighthouse tracking
      27031 # SteamVR
      27036 # SteamVR discovery
    ];
  };
}
