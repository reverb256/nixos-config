# Forge Host-Specific Configuration
# 10.1.1.130 - GPU Mining Rig (6 cores, 2x RTX 4060 + 2x RX 5700 XT)
# Desktop environment for remote access, but NO VR/gaming
# Mining-focused configuration
{ lib, pkgs, ... }:

{
  # ============================================================================
  # BOOTLOADER - systemd-boot
  # ============================================================================

  boot.loader = {
    systemd-boot.enable = true;
    efi.canTouchEfiVariables = true;
  };

  # ============================================================================
  # DESKTOP ENVIRONMENT - KDE Plasma 6
  # ============================================================================

  services = {
    xserver.enable = true;
    xserver.videoDrivers = ["nvidia"];
    displayManager = {
      sddm.enable = true;
      autoLogin = {
        enable = true;
        user = "j_kro";
      };
    };
    desktopManager.plasma6.enable = true;
  };

  # ============================================================================
  # HOSTNAME
  # ============================================================================

  # ============================================================================
  # AMD GPU SUPPORT
  # ============================================================================

  hardware.amdgpu.opencl.enable = true;

  # ============================================================================
  # HOSTNAME
  # ============================================================================

  networking.hostName = "forge";

  # ============================================================================
  # NETWORKING (Static IP via NetworkManager - required for desktop environment)
  # ============================================================================

  # ============================================================================
  # KERNEL PARAMETERS
  # ============================================================================

  # AMD GPU kernel parameters
  boot.kernelParams = [
    "amdgpu.noretry=0"
    "amdgpu.mcbp=1"
  ];

  environment.variables = {
    ROC_ENABLE_PRE_VEGA = "1";
  };

  # ============================================================================
  # NETWORKING (Static IP via NetworkManager - required for desktop environment)
  # ============================================================================

    # ============================================================================
    # NETWORKING (Static IP via NetworkManager - required for desktop environment)
    # ============================================================================

    # Wired ethernet only - disable wireless and avahi services
    networking.wireless.enable = lib.mkForce false;
    services.avahi = lib.mkForce {
      enable = false;
      nssmdns4 = false;
      openFirewall = false;
    };

    # Configure NetworkManager for static IP (desktop environment requires NetworkManager)
    networking.networkmanager = {
      enable = true;
      unmanaged = [];  # Let NetworkManager manage all interfaces
      ensureProfiles.profiles."eno1" = {
        connection = {
          id = "eno1";
          type = "ethernet";
          interface-name = "eno1";
        };
        ipv4 = {
          method = "manual";
          address1 = "10.1.1.130/24";
          gateway = "10.1.1.1";
          dns = "127.0.0.1,::1";  # Use local Unbound DNS
        };
      };
    };

   networking.dhcpcd.enable = false;
   networking.useDHCP = false;

  # ============================================================================
  # LOCAL HOSTS ENTRIES
  # ============================================================================

  networking.hosts = {
    "10.1.1.110" = ["zephyr"];
    "10.1.1.120" = ["nexus"];
    "10.1.1.130" = ["forge"];
    "10.1.1.140" = ["sentry"];
  };

  # ============================================================================
  # FIREWALL (Minimal - no VR ports on mining rig)
  # ============================================================================

  networking.firewall = {
    enable = true;
    allowedTCPPorts = [];
    allowedUDPPorts = [];
  };

  # ============================================================================
  # ROCm HIP symlink for OpenCL (fixes SIGSEGV crash)
  # ============================================================================

  systemd.tmpfiles.rules = let
    rocmEnv = pkgs.symlinkJoin {
      name = "rocm-combined";
      paths = with pkgs.rocmPackages; [
        clr
        clr.icd
        rocblas
        hipblas
        rpp
      ];
    };
  in [
    "L+ /opt/rocm - - - - ${rocmEnv}"
    "L+ /opt/rocm/hip - - - - ${pkgs.rocmPackages.clr}"
  ];

  # Mesa OpenCL packages for AMD GPU mining
  environment.systemPackages = with pkgs; [
    mesa.opencl  # Rusticl OpenCL implementation
  ];
}
