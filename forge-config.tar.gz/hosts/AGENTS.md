# HOSTS KNOWLEDGE BASE

**Generated:** 2026-01-19
**Scope:** Multi-Host Cluster Configuration
**Complexity:** Medium (4 hosts, distributed builds)

## OVERVIEW
Distributed NixOS build cluster with 4 hosts: zephyr (master), nexus (build/backup), forge (compute), sentry (monitoring). Total 51 cores across cluster.

## STRUCTURE
```
hosts/
├── nexus/
│   ├── configuration.nix      # Build/backup server (8 cores)
│   └── hardware-configuration.nix
├── forge/
│   ├── configuration.nix      # Compute server (16 cores, dual GPU)
│   ├── hardware-configuration.nix
│   └── modules/
│       └── system.nix         # Forge-specific optimizations
└── sentry/
    ├── configuration.nix      # Monitoring server (8 cores)
    └── hardware-configuration.nix
```

## WHERE TO LOOK
| Task | Location | Notes |
|------|----------|-------|
| Master config | ./configuration.nix | Zephyr (16 cores, RTX 3090) |
| Build/backup | hosts/nexus/configuration.nix | Nexus (8 cores, storage focus) |
| Compute/GPU | hosts/forge/configuration.nix | Forge (16 cores, dual GPU) |
| Monitoring | hosts/sentry/configuration.nix | Sentry (8 cores) |
| Cluster deployment | colmena.nix | Multi-host deployment |
| Build pool | machines.nix | 51-core distributed builds |

## HOST CONFIGURATIONS

### Zephyr (Master) - 10.1.1.110
- **CPU**: 16 cores (Ryzen 5950X)
- **GPU**: RTX 3090 (VR/gaming/mining)
- **Role**: Master workstation, build coordination
- **Mining**: 16 threads XMRig + lolMiner
- **Desktop**: Full KDE Plasma 6 with Wayland
- **Features**: VR, AI assistant, anime game launchers

### Nexus (Build/Backup) - 10.1.1.120
- **CPU**: 8 cores (Ryzen 1700)
- **GPU**: 2x RTX 3060 Ti (NVIDIA)
- **Role**: Build node, backup storage
- **Mining**: 12 threads XMRig + lolMiner
- **Desktop**: Full KDE Plasma 6 with Wayland
- **Drivers**: NVIDIA proprietary
- **Storage**: rclone, backup services

### Forge (Compute) - 10.1.1.130
- **CPU**: 16 cores (Ryzen 3700X)
- **GPU**: RTX 4060 (NVIDIA) + RX 5700 XT (AMD)
- **Role**: Heavy build, GPU compute
- **Mining**: 4 threads XMRig + lolMiner
- **Desktop**: Full KDE Plasma 6 with Wayland
- **Drivers**: NVIDIA proprietary (primary)
- **Features**: Multi-GPU, compute optimizations

### Sentry (Monitoring) - 10.1.1.140
- **CPU**: 8 cores (Ryzen 1700)
- **GPU**: RX 5600 XT (AMD only)
- **Role**: Monitoring, light builds
- **Mining**: 8 threads XMRig + lolMiner
- **Desktop**: Full KDE Plasma 6 with Wayland
- **Drivers**: AMDGPU open source
- **Features**: System monitoring

## CODE MAP
| Symbol | Type | Location | Role |
|--------|------|----------|------|
| nixosConfigurations.zephyr | AttrSet | flake.nix:73 | Master host |
| nixosConfigurations.nexus | AttrSet | flake.nix:142 | Build host |
| nixosConfigurations.forge | AttrSet | flake.nix:158 | Compute host |
| nixosConfigurations.sentry | AttrSet | flake.nix:174 | Monitor host |
| builders | String | configuration.nix:58 | Distributed build pool |
| colmena | AttrSet | colmena.nix | Multi-host deployment |

## CONVENTIONS
- **Static IPs**: 10.1.1.110-140 range
- **Host modules**: Import ../../modules/ pattern
- **Hardware configs**: Auto-generated, DO NOT EDIT
- **Mining threads**: Host-specific (16/12/4/8)
- **Build capacity**: 32/8/3/8 max jobs per host
- **Shared modules**: All hosts import from ../../modules/

## ANTI-PATTERNS (HOSTS)
- **NEVER** edit hardware-configuration.nix files
- **NEVER** duplicate module imports across hosts
- **NEVER** use different mining wallet formats
- **NEVER** hardcode host-specific values in shared modules
- **ALWAYS** use relative imports: ../../modules/
- **ALWAYS** maintain consistent naming conventions
- **ALWAYS** update machines.nix when adding hosts

## UNIQUE STYLES
- **Distributed builds**: 51-core pool with SSH
- **Host-specific mining**: Thread counts matched to CPU
- **Multi-GPU setup**: Forge with NVIDIA + AMD
- **Backup specialization**: Nexus with rclone services
- **Monitoring focus**: Sentry with system metrics
- **Colmena deployment**: Multi-host management
- **Parallel deployment**: GNU parallel for cluster ops

## COMMANDS
```bash
# Deploy to all hosts
just deploy-all

# Deploy to specific host
just deploy nexus

# Check cluster status
just cluster-status

# Build with distributed compilation
nix build --builders-use-substitutes nixpkgs#package

# Monitor cluster resources
just cluster-resources
```

## NOTES
- **Build pool**: 51 cores total (32+8+3+8)
- **Network**: All hosts on 10.1.1.0/24 subnet
- **SSH**: Passwordless sudo for j_kro user
- **Mining**: Kryptex pool with krxXVNVMM7.<hostname> wallets
- **Deployment**: Colmena + custom parallel scripts
- **Storage**: Nexus handles backup storage duties
- **GPU diversity**: Different NVIDIA models per host