# Colmena Refactor Handoff

**Created:** 2026-01-22
**Status:** Structural validation blocked (colmena.nix output format issue)

---

## Context

User requested "harsh reality" audit and refactor of NixOS configuration to work optimally with Colmena for distributed deployment. A git worktree was created at `/etc/nixos-colmena/` on branch `colmena-refactor`.

**Original issue**: Configuration had hardcoded IPs in modules, duplicate patterns, and was not structured for Colmena's `defaults` pattern.

---

## Completed Work

### 1. Created New Modules

**`modules/base.nix`** - Common settings for ALL hosts:
- Timezone: `America/Winnipeg`
- Locale: `en_CA.UTF-8`
- Fonts: Noto (CJK included), JetBrains Mono
- CPU governor: `performance`
- ZRAM swap: 50%, zstd compression
- Systemd OOM daemon

**`modules/desktop.nix`** - Wayland-only KDE Plasma 6:
- SDDM with Wayland ONLY (X11 disabled)
- KDE Plasma 6 + essential packages
- Force Wayland env vars:
  - `QT_QPA_PLATFORM=wayland`
  - `GDK_BACKEND=wayland`
  - `XDG_SESSION_TYPE=wayland`
- PipeWire audio
- NVIDIA modesetting (`nvidia.settings = { inheritLibs = true; }`)

**`modules/networking-shared.nix`** - No hardcoded IPs:
- NetworkManager (basic, for all hosts)
- Analytics/telemetry blocklist (VRChat, Unity, telemetry domains)
- Unbound DNS with DoT (Quad9, Google, Cloudflare on port 853)
- Avahi daemon (device discovery)
- Firewall (base rules)
- Tailscale VPN (disabled by default)

**`modules/gaming.nix`** - VR/gaming (NOT for forge):
- Steam + SteamVR + WiVRn
- GameMode with NVIDIA overclock (+150MHz)
- Smart mining pause (auto-pause during VR/gaming)
- VR slices (vr.slice, gaming.slice for CPU priority)
- VR ports in firewall (9757-9760, 27031, 27036)

**`modules/mining.nix`** - Mining configuration:
- CPU mining: XMRig (configurable pool/wallet)
- GPU mining: lolMiner (NVIDIA + AMD support)
- Health monitoring (5-min timer, restart if hashrate=0)
- Smart pause support (stops mining during VR/gaming)

### 2. Created Host-Specific Files

**`hosts/zephyr/default.nix`**:
```nix
{
  imports = [ ../modules/base.nix ../modules/desktop.nix ../modules/networking-shared.nix ../modules/gaming.nix ];
  networking.hostName = "zephyr";
  networking.interfaces.enp38s0.ipv4.addresses = [{ address = "10.1.1.110"; prefixLength = 24; }];
  services.mining = {
    enable = true;
    cpu.enable = true;
    gpu.enable = true;
    gpu.miners = [ "lolminer-nvidia" ];
  };
}
```

**`hosts/nexus/default.nix`**:
```nix
{
  imports = [ ../modules/base.nix ../modules/desktop.nix ../modules/networking-shared.nix ../modules/mining.nix ];
  networking.hostName = "nexus";
  networking.interfaces.enp7s0.ipv4.addresses = [{ address = "10.1.1.120"; prefixLength = 24; }];
  services.mining = {
    enable = true;
    cpu.enable = true;
    gpu.enable = true;
    gpu.miners = [ "lolminer-nvidia" "lolminer-amd" ];
  };
}
```

**`hosts/forge/default.nix`**:
```nix
{
  imports = [ ../modules/base.nix ../modules/desktop.nix ../modules/networking-shared.nix ../modules/mining.nix ];
  networking.hostName = "forge";
  networking.interfaces.eno1.ipv4.addresses = [{ address = "10.1.1.130"; prefixLength = 24; }];
  services.mining = {
    enable = true;
    cpu.enable = false;  # Pure GPU mining rig
    gpu.enable = true;
    gpu.miners = [ "lolminer-nvidia" "lolminer-amd" ];
  };
  boot.initrd.kernelModules = [ "amdgpu" ];  # Early AMD init
  hardware.amdgpu.initrd = true;
  hardware.rocm = { enable = true; };  # ROCm HIP support
}
```

**`hosts/sentry/default.nix`**:
```nix
{
  imports = [ ../modules/base.nix ../modules/desktop.nix ../modules/networking-shared.nix ../modules/mining.nix ];
  networking.hostName = "sentry";
  networking.interfaces.enp7s0.ipv4.addresses = [{ address = "10.1.1.140"; prefixLength = 24; }];
  services.mining = {
    enable = true;
    cpu.enable = true;  # CPU-only mining
    gpu.enable = false;
  };
}
```

### 3. Restructured `colmena.nix`

```nix
{ inputs, self }:

let
  # Shared module imports
  baseModules = [
    ./modules/base.nix
    ./modules/desktop.nix
    ./modules/networking-shared.nix
    ./modules/mining.nix
  ];
in
{
  defaults = {
    imports = baseModules;
    nix.settings.trusted-users = [ "root" "j_kro" ];
  };

  "zephyr" = {
    imports = baseModules ++ [ ./modules/gaming.nix ];
    networking.hostName = "zephyr";
    networking.interfaces.enp38s0.ipv4.addresses = [{ address = "10.1.1.110"; prefixLength = 24; }];
    services.mining.enable = true;
    services.mining.cpu.enable = true;
    services.mining.gpu.enable = true;
  };

  "nexus" = {
    networking.hostName = "nexus";
    networking.interfaces.enp7s0.ipv4.addresses = [{ address = "10.1.1.120"; prefixLength = 24; }];
    services.mining.enable = true;
    services.mining.cpu.enable = true;
    services.mining.gpu.enable = true;
  };

  "forge" = {
    networking.hostName = "forge";
    networking.interfaces.eno1.ipv4.addresses = [{ address1.1.130"; prefixLength = "10. = 24; }];
    services.mining.enable = true;
    services.mining.cpu.enable = false;
    services.mining.gpu.enable = true;
    boot.initrd.kernelModules = [ "amdgpu" ];
    hardware.amdgpu.initrd = true;
    hardware.rocm.enable = true;
  };

  "sentry" = {
    networking.hostName = "sentry";
    networking.interfaces.enp7s0.ipv4.addresses = [{ address = "10.1.1.140"; prefixLength = 24; }];
    services.mining.enable = true;
    services.mining.cpu.enable = true;
    services.mining.gpu.enable = false;
  };
}
```

### 4. Simplified `flake.nix`

```nix
{
  description = "NixOS configuration with Colmena";

  inputs = {
    nixpkgs.url = "github:nixos/nixpkgs/nixos-unstable";
    nixpkgs-stable.url = "github:nixos/nixpkgs/nixos-24.11";
    home-manager.url = "github:nix-community/home-manager/release-24.11";
    home-manager.inputs.nixpkgs.follows = "nixpkgs-stable";
    nix-gaming.url = "github:nix-gaming/nix-gaming";
    ezkea.url = "github:nix-community/ezkea";
    nixcord.url = "github:nix-community/nixcord";
  };

  outputs = inputs @ { self, ... }: {
    overlays = {
      mining-overlay = import ./modules/mining-overlay.nix;
    };
    colmena = import ./colmena.nix { inherit inputs self; };
  };
}
```

### 5. Deleted Redundant Files

| Deleted File | Reason |
|--------------|--------|
| `modules/plasma.nix` | Merged into `modules/desktop.nix` |
| `modules/networking.nix` | Had hardcoded zephyr IP, replaced with networking-shared.nix |
| `hosts/nexus/configuration.nix` | Now defined in colmena.nix |
| `hosts/forge/configuration.nix` | Now defined in colmena.nix |
| `hosts/sentry/configuration.nix` | Now defined in colmena.nix |

---

## Cluster Hardware Summary

| Host | IP | CPU | GPU | Role | Mining |
|------|-----|-----|-----|------|--------|
| zephyr | 10.1.1.110 | Ryzen 9 5950X (32c) | RTX 3090 (1x) | Gaming/VR + Mining | CPU + 1 GPU |
| nexus | 10.1.1.120 | Ryzen 9 3900X (24c) | RTX 3060 Ti (2x) | Build node + Mining | CPU + 2 GPUs |
| forge | 10.1.1.130 | 6 cores | RTX 4060 (2x) + RX 5700 XT (2x) | Mining only | 4 GPUs |
| sentry | 10.1.1.140 | Ryzen 7 1700 (8c) | RX 5600 XT (1x, display) | Monitoring + Mining | CPU only |

---

## Blocking Issue

**`nix flake check` fails**: "unknown flake output 'colmena'"

The issue is that `colmena.nix` is a function that returns an attribute set, but the flake output schema may not be correct for Colmena. Colmena expects a specific structure.

### Potential Solutions

1. **Colmena from flake**: Colmena can be invoked via `nix run` without being a flake output:
   ```bash
   nix run github:nix-community/colmena -- --help
   ```

2. **Correct flake output format**: The colmena output should be an attribute set with the proper structure. Research the correct format.

3. **Use colmena CLI directly**: Skip flake integration, run colmena directly:
   ```bash
   colmena build
   colmena apply
   ```

### Validation Commands to Try

```bash
# Check flake structure
nix eval /etc/nixos-colmena#colmena --apply 'x: builtins.attrNames x'

# Try colmena CLI
nix run github:nix-community/colmena -- build --help

# Direct evaluation
nix-instantiate --eval -E 'import ./colmena.nix { inputs = {}; self = {}; }' 2>&1 | head -50
```

---

## Remaining Tasks

1. **Fix Colmena integration** - Resolve the flake output format issue
2. **Validate configuration** - Run `colmena build` or equivalent
3. **Verify hardware configs** - Check `hosts/*/hardware-configuration.nix` exists
4. **Test deployment** - `colmena apply --dry-run` on each host
5. **Home Manager** - Ensure `home.nix` is imported for zephyr (j_kro user)
6. **Secrets** - Verify age secrets exist at expected paths

---

## Key Architecture Decisions

1. **All hosts get desktop environment** - Even mining-only hosts (forge, sentry) get KDE Plasma for remote access
2. **Wayland-only** - Force Wayland via environment variables, no X11 fallback
3. **Single source of truth** - All host config in `colmena.nix` using `defaults` pattern
4. **No hardcoded IPs in modules** - Host-specific networking in `colmena.nix` host definitions
5. **Forge = mining only** - No gaming/VR modules, pure mining with ROCm support
6. **Smart mining pause** - Mining stops automatically during VR/gaming sessions

---

## Important Notes

- **Forge uses ROCm** - AMD GPUs need `hardware.rocem.enable = true` and early `amdgpu` initrd
- **VR ports only on zephyr** - VRChat ports (9757-9760) only in zephyr's firewall
- **Sentry CPU-only** - RX 5600 XT is display-only, not for mining
- **Home Manager** - Not imported in colmena.nix yet; needs to be added for user config

---

## Files Reference

```
/etc/nixos-colmena/
├── flake.nix                    # Simplified flake with colmena output
├── colmena.nix                  # Colmena config with defaults pattern
├── modules/
│   ├── base.nix                 # Common settings (timezone, locale, fonts, swap)
│   ├── desktop.nix              # KDE Plasma 6 + Wayland + PipeWire
│   ├── gaming.nix               # VR/SteamVR/WiVRn + GameMode (NOT for forge)
│   ├── mining.nix               # XMRig + lolMiner + health monitoring
│   ├── networking-shared.nix    # NetworkManager, DNS, firewall, blocklist
│   └── mining-overlay.nix       # Custom package overlays
├── hosts/
│   ├── zephyr/default.nix       # Gaming host (can be removed, now in colmena.nix)
│   ├── nexus/default.nix        # Build host (can be removed, now in colmena.nix)
│   ├── forge/default.nix        # Mining rig (can be removed, now in colmena.nix)
│   └── sentry/default.nix       # Monitoring host (can be removed, now in colmena.nix)
├── home.nix                     # Home Manager config (needs integration)
└── packages/
    ├── lolminer.nix             # GPU miner package
    └── xmrig.nix                # CPU miner package
```

---

## Commands for Continuation

```bash
# Enter worktree
cd /etc/nixos-colmena

# Check current state
git status
git diff --stat

# Validate structure
nix flake check 2>&1 | head -20
nix eval .#colmena --apply 'x: builtins.attrNames x' 2>&1

# Try colmena directly
nix run github:nix-community/colmena -- build --help

# Test on single host
nix run github:nix-community/colmena -- build --on zephyr --dry-run

# When ready to apply
nix run github:nix-community/colmena -- apply --on zephyr
```
