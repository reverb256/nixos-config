# Binary Cache Module
# Enables zephyr as a binary cache server for the cluster using nix-serve
{ config, lib, pkgs, ... }:

let
  cfg = config.services.binary-cache;
in
{
  options.services.binary-cache = {
    enable = lib.mkEnableOption "Enable zephyr as binary cache server for cluster";
    hostName = lib.mkOption {
      type = lib.types.str;
      default = "zephyr";
      description = "Hostname of the cache server";
    };
    port = lib.mkOption {
      type = lib.types.port;
      default = 8080;
      description = "Port for the binary cache HTTP server";
    };
    cacheDir = lib.mkOption {
      type = lib.types.path;
      default = "/nix/store";
      description = "Directory containing Nix store to serve";
    };
  };

  config = lib.mkIf cfg.enable {
    # nix-serve handles the Nix binary cache protocol with automatic signing
    services.nix-serve = {
      enable = true;
      port = cfg.port;
      secretKeyFile = "/etc/nixos/secrets/nix-cache-key.sec";
      # Optional: restrict to local network
      bindAddress = "0.0.0.0";
    };

    # Open port in firewall for local network access
    networking.firewall.allowedTCPPorts = [cfg.port];

    # Create a helper script to upload closures to the cache
    environment.systemPackages = [
      (pkgs.writeShellScriptBin "cache-push" ''
        #!/bin/bash
        # Upload a system closure to the local binary cache
        # Usage: cache-push <host>
        
        set -euo pipefail
        
        if [ $# -lt 1 ]; then
          echo "Usage: cache-push <hostname>"
          echo "  Example: cache-push nexus"
          echo ""
          echo "Uploads current system closure to zephyr's binary cache."
          echo "Other nodes can then fetch pre-built binaries from zephyr."
          exit 1
        fi
        
        HOST="''$1"
        CACHE_URL="http://${cfg.hostName}:${toString cfg.port}"
        
        echo "Uploading current system closure to ''${CACHE_URL}..."
        echo "Target host: ''${HOST}"
        
        # Get the current system closure and push to zephyr cache
        nix copy --to "ssh://root@''${HOST}?remote-store=''${CACHE_URL}" \
          --no-check-sigs \
          /run/current-system
        
        echo ""
        echo "Done! Other nodes can now fetch from ''${CACHE_URL}"
      '')
    ];
  };
}
