{
  config,
  lib,
  pkgs,
  ...
}:
with lib; let
  cfg = config.services.mining;
  miningServices = import ./lib/mining-services.nix {inherit lib pkgs;};

  # Get NVIDIA paths from ZEN kernel (same as hardware.nvidia.package)
  # This ensures kernel modules and user-space libraries match
  nvidiaStable = pkgs.linuxPackages_zen.nvidiaPackages.stable;
  nvidiaLibPath = "${nvidiaStable}/lib";
  nvidiaSmipath = "${nvidiaStable.bin}/bin/nvidia-smi";

  # Wrapper for NVIDIA OpenCL inside steam-run
  lolminerWrapper = pkgs.writeShellScriptBin "lolminer-wrapper" ''
    #!/usr/bin/env bash
    NVIDIA_OPENCL="${nvidiaLibPath}/libnvidia-opencl.so"
    mkdir -p /etc/OpenCL/vendors
    echo "''${NVIDIA_OPENCL}" > /etc/OpenCL/vendors/nvidia.icd
    export LD_LIBRARY_PATH="${nvidiaLibPath}:/run/opengl-driver/lib:$LD_LIBRARY_PATH"
    export GPU_MAX_HEAP_SIZE=100
    export GPU_MAX_ALLOC_PERCENT=100
    exec ${pkgs.lolminer}/bin/lolMiner "$@"
  '';

  # Wrapper for AMD OpenCL inside steam-run
  # RX 5700 XT = NAVI10 (gfx1010)
  # Use ROCm OpenCL with working configuration for Navi10
  lolminerAmdWrapper = pkgs.writeShellScriptBin "lolminer-amd-wrapper" ''
    #!/usr/bin/env bash
    # Set up OpenCL for AMD GPUs using ROCm (working configuration)
    mkdir -p /etc/OpenCL/vendors

    # Use ROCm OpenCL driver
    echo "${pkgs.rocmPackages.clr}/lib/libamdocl64.so" > /etc/OpenCL/vendors/amdocl64.icd 2>/dev/null || true

    # ROCm environment for Navi10
    export LD_LIBRARY_PATH="/opt/rocm/lib:/opt/rocm/hip/lib:/opt/rocm/lib:/run/opengl-driver/lib:/run/current-system/sw/lib:$LD_LIBRARY_PATH"
    export HSA_OVERRIDE_GFX_VERSION=10.3.0
    export ROC_ENABLE_PRE_VEGA=1
    export GPU_MAX_HEAP_SIZE=100
    export GPU_MAX_ALLOC_PERCENT=100
    exec ${pkgs.lolminer}/bin/lolMiner "$@"
  '';

  monitorScript = pkgs.writeShellScriptBin "miner-monitor" ''
    #!/usr/bin/env bash
    API_RESPONSE=$(curl -s http://localhost:4068/summary 2>/dev/null || echo "")
    if [[ -z "$API_RESPONSE" || "$API_RESPONSE" == *"ERROR"* ]]; then
      echo "API check failed - restarting lolMiner"
      systemctl restart lolminer-nvidia
    else
      echo "Mining service healthy"
    fi
  '';
in {
  options.services.mining = {
    enable = mkEnableOption "Robust Mining Services";
    user = mkOption {
      type = types.str;
      default = "j_kro";
    };

    lolminer = {
      enable = mkEnableOption "lolMiner Service";
      algorithm = mkOption {
        type = types.str;
        default = "CR29";
      };
      pool = mkOption {
        type = types.str;
        default = "stratum+ssl://xtm-c29-us.kryptex.network:8040";
      };
      wallet = mkOption {
        type = types.str;
        default = "krxXVNVMM7.zephyr";
      };
      nvidia = {
        enable = mkEnableOption "NVIDIA GPU Mining";
        devices = mkOption {
          type = types.str;
          default = "0";
        };
        powerLimit = mkOption {
          type = types.int;
          default = 250;
        };
        apiPort = mkOption {
          type = types.int;
          default = 4068;
        };
      };

      amd = {
        enable = mkEnableOption "AMD GPU Mining";
        devices = mkOption {
          type = types.str;
          default = "1";
        };
        powerLimit = mkOption {
          type = types.int;
          default = 140;
        };
        apiPort = mkOption {
          type = types.int;
          default = 4069;
        };
      };
    };

    xmrig = {
      enable = mkEnableOption "XMRig Service";
      pool = mkOption {
        type = types.str;
        default = "xmr.pool.gntl.co.uk:9999";
      };
      wallet = mkOption {
        type = types.str;
        default = "47wJ9d5bWD6f8BrWfnswURZJVCz5wTNHD3f3ZUWmfzhKcLn8JM65P9kTcNhh4gEhif8WwRSwLgRhhGLCfwErQehYPtHV8Wi";
      };
      threads = mkOption {
        type = types.int;
        default = 16;
      };
      httpToken = mkOption {
        type = types.str;
        default = "my-secret-token";
      };
    };
  };

  config = mkIf cfg.enable {
    boot.kernel.sysctl = {
      "vm.nr_hugepages" = 1280;
    };

    environment.systemPackages = [monitorScript lolminerWrapper];

    systemd = {
      services = {
        lolminer-nvidia = mkIf cfg.lolminer.nvidia.enable {
          description = "lolMiner NVIDIA Mining Service";
          wantedBy = ["multi-user.target"];
          after = ["NetworkManager.service" "nvidia-persistenced.service"];

          serviceConfig = {
            User = "root";
            Group = "mining";
            Slice = "mining.slice";
            ExecStartPre = [
              "${pkgs.bash}/bin/bash -c '${nvidiaSmipath} -pm 1 || true'"
              "${pkgs.bash}/bin/bash -c '${nvidiaSmipath} -pl ${toString cfg.lolminer.nvidia.powerLimit} || true'"
            ];
            ExecStart = "${pkgs.steam-run}/bin/steam-run ${lolminerWrapper}/bin/lolminer-wrapper --algo ${cfg.lolminer.algorithm} --pool ${cfg.lolminer.pool} --user ${cfg.lolminer.wallet} --devices ${cfg.lolminer.nvidia.devices} --apiport ${toString cfg.lolminer.nvidia.apiPort} --mode b --tls 1";
            ExecStopPost = "${pkgs.bash}/bin/bash -c '${nvidiaSmipath} -pl 350 || true'";
            Restart = "always";
            RestartSec = "30s";
            Environment = ["PATH=/run/current-system/sw/bin:$PATH"];
            NoNewPrivileges = false;
            PrivateTmp = true;
            PrivateDevices = false;
            ProtectKernelTunables = false;
            ProtectControlGroups = false;
            ProtectHostname = false;
            RestrictRealtime = true;
            LimitMEMLOCK = "4G";
          };
        };

         # AMD mining service - uses steam-run to bypass NixOS sandboxing
         lolminer-amd = mkIf cfg.lolminer.amd.enable {
           description = "lolMiner AMD Mining Service";
           wantedBy = ["multi-user.target"];
           after = ["NetworkManager.service"];

           serviceConfig = {
             Type = "simple";
             User = "j_kro";
             Group = "mining";
             Slice = "mining.slice";
             # Use steam-run with the AMD wrapper to bypass NixOS systemd sandboxing issues
             ExecStart = "${pkgs.steam-run}/bin/steam-run ${lolminerAmdWrapper}/bin/lolminer-amd-wrapper --algo ${cfg.lolminer.algorithm} --pool ${cfg.lolminer.pool} --user ${cfg.lolminer.wallet} --devices ${cfg.lolminer.amd.devices} --apiport ${toString cfg.lolminer.amd.apiPort} --mode b --tls 1";
             Restart = "always";
             RestartSec = 30;
             NoNewPrivileges = false;
             PrivateTmp = true;
           };
         };

        xmrig = mkIf cfg.xmrig.enable {
          description = "XMRig CPU Mining Service";
          wantedBy = ["multi-user.target"];
          after = ["NetworkManager.service"];

          serviceConfig = {
            User = "mining";
            Group = "mining";
            Slice = "mining.slice";
            ExecStart = "${pkgs.xmrig}/bin/xmrig -o ${cfg.xmrig.pool} -u ${cfg.xmrig.wallet} -t ${toString cfg.xmrig.threads} --http-port 8081 --http-access-token ${cfg.xmrig.httpToken} --http-restricted --randomx-1gb-pages --randomx-mode=fast --asm=auto --no-msr";
            Restart = "always";
            NoNewPrivileges = true;
            PrivateTmp = true;
            ProtectKernelTunables = true;
            ProtectControlGroups = true;
            RestrictRealtime = true;
            LimitMEMLOCK = "4G";
            CapabilityBoundingSet = "CAP_SYS_ADMIN CAP_SYS_NICE CAP_SYS_RAWIO";
            AmbientCapabilities = "CAP_SYS_ADMIN CAP_SYS_NICE CAP_SYS_RAWIO";
          };
        };

        test-service = {
          description = "Test Service for Mining Module";
          wantedBy = ["multi-user.target"];
          serviceConfig = {
            ExecStart = "/run/current-system/sw/bin/echo 'test service works'";
            Type = "oneshot";
          };
        };

        miner-monitor = mkIf cfg.lolminer.enable {
          script = "${monitorScript}/bin/miner-monitor";
          serviceConfig = {
            Type = "oneshot";
          };
        };
      };

      timers = {
        miner-monitor = mkIf cfg.lolminer.enable {
          wantedBy = ["timers.target"];
          timerConfig = {
            OnBootSec = "5m";
            OnUnitActiveSec = "5m";
            Unit = "miner-monitor.service";
          };
        };
      };
    };
  };
}
