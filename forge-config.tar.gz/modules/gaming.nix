# Gaming Module - SteamVR, WiVRn, Lighthouse Tracking, and Motion Tracking
# Enhanced with GameMode, NVENC, Smart Mining Management, and Performance Scheduling
# Complete VR setup for Quest Pro with 4 Tundra trackers
# NVIDIA RTX 3090 optimizations for multiple resolution targets
{
   config,
   lib,
   pkgs,
   ...
}:
with lib; {
  # ============================================================================
  # GAMEMODE - CPU/GPU Optimizations
  # ============================================================================

  programs.gamemode = {
    enable = true;
    settings = {
      general = {
        desiredgov = "performance"; # Use performance governor when entering GameMode
        inhibit_screensaver = true; # Disable screensaver during games
        require_display = true; # Require display to be active
        # GameMode integration with systemd slices
        use_systemd = true;

        # Additional GameMode optimizations
        softrealtime = "auto"; # Use SCHED_ISO when available
        renice = 15; # Increase priority for gaming processes
        ioprio = 0; # Highest I/O priority
      };
      gpu = {
        # NVIDIA Ampere (RTX 3090) specific settings
        nv_powermizer_mode = 1; # Prefer Maximum Performance
        nv_core_clock_mhz_offset = 150; # Slight overclock (+150MHz)
        nv_memory_transfer_rate_offset = 500; # Ampere memory overclock (+500MHz)
        nv_gpu_utilization = "1"; # Enable GPU utilization monitoring

        # Ampere-specific optimizations
        nv_preclocked_graphics_clock = "1"; # Enable preclocked graphics clock
        nv_preclocked_memory_clock = "1"; # Enable preclocked memory clock
        nv_preclocked_video_clock = "1"; # Enable preclocked video clock

        # DLSS and RTX optimizations for Ampere (RTX 3090)
        nv_dlss = "1"; # Enable DLSS if supported by game
        nv_reflex = "1"; # Enable NVIDIA Reflex for competitive gaming
        nv_api = "1"; # Enable NVIDIA API
      };

      # Custom scripts for GameMode events
      custom = {
        start = "/run/current-system/sw/bin/notify-send 'GameMode activated' 'Performance optimizations enabled'";
        end = "/run/current-system/sw/bin/notify-send 'GameMode deactivated' 'Normal performance restored'";
      };
    };
  };

  # ============================================================================
  # PERFORMANCE SCHEDULING - Systemd Slices & Real-time Priority
  # ============================================================================

  # Note: systemd slices not available in this nixpkgs version
  # High-priority slice for VR applications (Quest Pro 90Hz target)
  # systemd.slices."vr.slice" = {
  #   description = "VR Applications - Highest Priority (Quest Pro 90Hz)";
  #   # Memory and CPU allocation for VR workloads
  #   MemoryHigh = "80%";
  #   CPUQuota = "80%";
  #   TasksMax = 10000;
  # };

  # Gaming slice for high-performance games (4K 60Hz, 1440p 120Hz targets)
  # systemd.slices."gaming.slice" = {
  #   description = "Gaming Applications - High Priority (4K/1440p)";
  #   MemoryHigh = "70%";
  #   CPUQuota = "70%";
  #   TasksMax = 8000;
  # };

  # Performance slice for competitive gaming (1080p 60Hz targets)
  # systemd.slices."competitive.slice" = {
  #   description = "Competitive Gaming - Ultra Low Latency";
  #   MemoryHigh = "50%";
  #   CPUQuota = "60%";
  #   TasksMax = 5000;
  # };

  # ============================================================================
  # NVIDIA CONTROL PANEL EQUIVALENT - NixOS Configuration
  # ============================================================================

  # NVIDIA optimizations moved to modules/environment.nix for consolidation

  # ============================================================================
  # RESOLUTION-SPECIFIC OPTIMIZATIONS
  # ============================================================================

  # 1. Quest Pro 90Hz VR Optimizations
  systemd.services."vr-90hz-optimization" = {
    description = "Optimize for Quest Pro 90Hz VR streaming";
    serviceConfig = {
      Type = "oneshot";
      RemainAfterExit = "yes";
      ExecStart = ''
        #!/bin/bash
        # Quest Pro specific optimizations
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "GPUPowerMizerMode=1"  # Maximum performance
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "GPUGraphicsClockOffset[3:0]=150"  # Core overclock
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "GPUMemoryTransferRateOffset[3:0]=200"  # Conservative memory overclock
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "GPUFanControlState=1"  # Enable fan control
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "GPUTargetFanSpeed=70"  # Set fan speed for cooling
      '';
      ExecStop = ''
        #!/bin/bash
        # Reset to default VR settings
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "GPUPowerMizerMode=0"
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "GPUGraphicsClockOffset[3:0]=0"
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "GPUMemoryTransferRateOffset[3:0]=0"
      '';
    };
    # Note: wantedBy disabled due to slices not available
    # wantedBy = ["vr.slice"];
  };

  # 2. 4K 60Hz TV Gaming Optimizations
  systemd.services."4k-60hz-optimization" = {
    description = "Optimize for 4K 60Hz TV gaming";
    serviceConfig = {
      Type = "oneshot";
      RemainAfterExit = "yes";
      ExecStart = ''
        #!/bin/bash
        # 4K specific optimizations
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "GPUPowerMizerMode=1"
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "GPUGraphicsClockOffset[3:0]=100"  # Moderate overclock
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "GPUMemoryTransferRateOffset[3:0]=300"

        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "TextureFilterQuality=2"  # High quality
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "TextureFilterAnisotropicSampleLocation=1"
      '';
    };
    # Note: wantedBy disabled due to slices not available
    # wantedBy = ["gaming.slice"];
  };

  # 3. 1440p 120Hz Gaming Optimizations
  systemd.services."1440p-120hz-optimization" = {
    description = "Optimize for 1440p 120Hz competitive gaming";
    serviceConfig = {
      Type = "oneshot";
      RemainAfterExit = "yes";
      ExecStart = ''
        #!/bin/bash
        # 1440p 120Hz optimizations
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "GPUPowerMizerMode=1"
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "GPUGraphicsClockOffset[3:0]=200"  # Higher overclock
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "GPUMemoryTransferRateOffset[3:0]=300"
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "AllowFlipping=1"  # Enable flipping
      '';
    };
    # Note: wantedBy disabled due to slices not available
    # wantedBy = ["competitive.slice"];
  };

  # 4. 1080p 60Hz Monitor Optimizations
  systemd.services."1080p-60hz-optimization" = {
    description = "Optimize for 1080p 60Hz monitor gaming";
    serviceConfig = {
      Type = "oneshot";
      RemainAfterExit = "yes";
      ExecStart = ''
        #!/bin/bash
        # 1080p optimizations (minimal overclock for efficiency)
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "GPUPowerMizerMode=1"
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "GPUGraphicsClockOffset[3:0]=50"   # Light overclock
        ${pkgs.linuxPackages_zen.nvidiaPackages.stable}/bin/nvidia-settings -a "GPUMemoryTransferRateOffset[3:0]=200"
      '';
    };
    # Note: wantedBy disabled due to slices not available
    # wantedBy = ["competitive.slice"];
  };

  # ============================================================================
  # GPU GOVERNOR MANAGEMENT
  # ============================================================================

  powerManagement = {
    cpuFreqGovernor = "performance"; # Performance mode for gaming
  };

  # ============================================================================
  # STEAM - Full VR Support with NVENC Optimizations
  # ============================================================================

  # Note: Following LVRA recommendations for NixOS
  # https://lvra.gitlab.io/docs/distros/nixos/#steam-games-and-openvr-apps

  programs.steam = {
    enable = true;
    extraCompatPackages = with pkgs; [
      proton-ge-bin
    ];
  };

  # ============================================================================
  # NVIDIA VR OPTIMIZATIONS - NVENC, Low Latency, VR Ready
  # ============================================================================

  # NVIDIA-specific VR optimizations (consolidated in modules/environment.nix)

  # ============================================================================
  # WI VRN - Wireless VR Streaming for Quest Pro
  # ============================================================================
  # Note: Following LVRA recommendations for NixOS
  # https://lvra.gitlab.io/docs/fossvr/wivrn/#nixos

  services.wivrn = {
    enable = true;
    openFirewall = true;
    defaultRuntime = true;
    config.enable = true;
    config.json = {
      # Quest Pro specific optimizations for 90Hz target
      device = {
        name = "Quest Pro";
        type = "quest_pro";
        # High resolution for Quest Pro at 90Hz
        resolution = "1800x1920"; # Native Quest Pro resolution per eye
        refresh_rate = 90;
      };

      # Streaming optimizations for RTX 3090 at 90Hz
      stream = {
        codec = "hevc"; # HEVC for better compression at 90Hz
        targetBitrate = 150; # Optimized bitrate for RTX 3090 at 90Hz (Mbps)
        spatial = true; # Enable spatial encoding
        temporal = true; # Enable temporal encoding

        # RTX 3090 specific optimizations for 90Hz
        nvidiaEncoder = {
          preset = "p7"; # Quality preset for VR (highest quality)
          tune = "ll"; # Low latency tuning for 90Hz
          profile = "high"; # High profile for better quality
          # 90Hz specific settings optimized for RTX 3090
          rc = "vbr"; # Variable bitrate for 90Hz
          b = "150000"; # 150Mbps target (RTX 3090 can handle this)
          maxrate = "200000"; # Max bitrate cap
          bufsize = "300000"; # Buffer size for smooth streaming
          gop = "60"; # GOP size for 90Hz (1 second)
          keyint = "60"; # Keyframe interval
          refs = "4"; # Reference frames
          bframes = "2"; # B-frames for better compression
          twoPass = "quarter_res"; # Two-pass encoding for quality
          aq = "spatial"; # Adaptive quantization
          temporal_aq = "1"; # Temporal AQ for better motion
          nonref_p = "1"; # Non-reference P-frames
          strict_gop = "1"; # Strict GOP for consistent quality
        };
        encoder = "nvidia"; # Use NVIDIA NVENC
      };

      # Network optimizations for 90Hz streaming
      network = {
        protocol = "udp"; # Lower latency than TCP
        localOptimization = true; # Optimize for local network
        # 90Hz specific latency settings
        frameTiming = {
          targetLatencyMs = 12; # Lower latency for 90Hz
          jitterBufferMs = 3; # Smaller jitter buffer for 90Hz
        };
      };

      # Debug and logging for 90Hz troubleshooting
      debug = {
        logLevel = "info";
        enableStats = true;
      };
    };
  };

  # ============================================================================
  # UDEV RULES - VR Device Permissions
  # ============================================================================

  services.udev.extraRules = ''
    # Quest Pro USB rules
    SUBSYSTEM=="usb", ATTR{idVendor}=="2833", ATTR{idProduct}=="0181", MODE="0666", GROUP="plugdev"

    # Lighthouse base station rules
    SUBSYSTEM=="usb", ATTR{idVendor}=="28de", ATTR{idProduct}=="2101", MODE="0666", GROUP="plugdev"
    SUBSYSTEM=="usb", ATTR{idVendor}=="28de", ATTR{idProduct}=="2102", MODE="0666", GROUP="plugdev"

    # Tundra tracker rules
    SUBSYSTEM=="usb", ATTR{idVendor}=="1234", ATTR{idProduct}=="5678", MODE="0666", GROUP="plugdev"

     # HTC Vive/Valkyrie controllers
     SUBSYSTEM=="usb", ATTR{idVendor}=="0bb4", ATTR{idProduct}=="2c87", MODE="0666", GROUP="plugdev"

     # DualSense (PS5) controllers - USB access only, let Wine handle hidraw
     SUBSYSTEM=="usb", ATTR{idVendor}=="054c", ATTR{idProduct}=="0ce6", MODE="0666", GROUP="plugdev"
     SUBSYSTEM=="usb", ATTR{idVendor}=="054c", ATTR{idProduct}=="0df2", MODE="0666", GROUP="plugdev"

     # Valve Index controllers
    SUBSYSTEM=="usb", ATTR{idVendor}=="28de", ATTR{idProduct}=="2101", MODE="0666", GROUP="plugdev"
  '';

  # ============================================================================
  # KERNEL MODULES - VR Device Support
  # ============================================================================

  boot.kernelModules = [
    # Required for USB VR devices
    "usbhid"
    "uvcvideo"
    # Required for NVIDIA VR support
    "nvidia-uvm"
    # Required for WiVRn networking
    "wireguard"
    # Required for motion tracking
    "hid-sensor-hub"
  ];

  # ============================================================================
  # PERFORMANCE TUNING - VR-Specific Optimizations
  # ============================================================================

  # Low-latency kernel parameters (in addition to boot.kernelParams)
  boot.extraModprobeConfig = ''
    # Disable CPU frequency scaling for consistent VR performance
    options cpufreq_performance ignore_cpu_freq=1

     # Audio stability - prevent crackling during gaming
     options snd_hda_intel power_save=0
     options snd_hda_intel power_save_controller=N
     # Conservative audio buffer settings
     options snd_hda_intel bdl_pos_adj=0  # Disable buffer position adjustments

    # USB optimization for VR devices
    options usbcore autosuspend=-1

    # NVIDIA VR optimizations for RTX 3090
    options nvidia "NVreg_RegistryDwords=RMIntrLockingMode=1;NVreg_EnableResizableBar=1"
  '';

  # ============================================================================
  # PACKAGES - VR Applications and Tools
  # ============================================================================

  environment.systemPackages = with pkgs; [
    # VR runtimes and tools
    wivrn
    openxr-loader

    # SteamVR support
    steam-run

    # Performance monitoring and optimization tools
    gamescope
    mangohud
    goverlay
    nvtopPackages.full

    # proton-cachyos temporarily disabled
    gamemode
    scx.full
  ];

  # ============================================================================
  # GAMESCOPE CONFIGURATION - Microcompositor for Gaming
  # ============================================================================

  programs.gamescope = {
    enable = true;
    capSysNice = true; # Allow gamescope to renice itself

    # Environment variables for gamescope
    env = {
      # Vulkan and NVIDIA optimizations
      __GL_SHADER_DISK_CACHE_SKIP_CLEANUP = "1";
      __GL_SHADER_DISK_CACHE_SIZE = "1073741824";
      __GL_SHADER_DISK_CACHE_PATH = "/tmp/nvidia-shader-cache";

      # Ampere optimizations
      __GLX_FORCE_MONO = "0";
      __GL_ALLOW_FXAA_USAGE = "1";

      # HDR support
      ENABLE_HDR_WSI = "1";
      DXVK_HDR = "1";
    };

    # Gamescope configuration - VRR DISABLED, everything else enabled
    args = [
      # NVIDIA Backend (Better compatibility for RTX 3090)
      "--backend sdl"

      # Performance optimizations
      "--immediate-flips" # Lowest latency flips
      "--rt" # Real-time priority

      # HDR enabled (display can handle it, just not VRR)
      "--hdr-enabled"
      "--hdr-itm-enable" # Inverse tone mapping for better HDR

      # Steam integration
      "--steam"
      "--xwayland-count 2"

      # Full capabilities maintained
      "--force-composition-pipeline=auto"
      "--prefer-output=auto"
      "--expose-wayland" # Wayland support
    ];
  };

  # ============================================================================
  # ASSERTIONS - VR Configuration Validation
  # ============================================================================

  # Enable Avahi for device discovery
  services.avahi = {
    enable = true;
    nssmdns4 = true;
    publish = {
      enable = true;
      addresses = true;
      workstation = true;
    };
  };

  assertions = [
    {
      assertion = config.programs.steam.enable;
      message = "Steam must be enabled for VR support";
    }
    {
      assertion = config.services.wivrn.enable;
      message = "WiVRn must be enabled for VR support";
    }
    {
      assertion = config.hardware.nvidia.package != null;
      message = "NVIDIA drivers are required for optimal VR performance";
    }
  ];
}
