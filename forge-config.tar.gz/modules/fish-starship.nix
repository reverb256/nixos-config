_: {
  config = {
    # Fish Shell Configuration
    programs.fish = {
      enable = true;
      useBabelfish = true; # Translate shell aliases
      vendor = {
        completions.enable = true;
        config.enable = true;
        functions.enable = true;
      };
      shellAliases = {
        # Navigation aliases
        ll = "ls -la --color=auto";
        la = "ls -la --color=auto";
        l = "ls --color=auto";
        ".." = "cd ..";
        "..." = "cd ../..";
        "...." = "cd ../../..";
        "....." = "cd ../../../..";

        # Git aliases
        gs = "git status";
        ga = "git add";
        gc = "git commit";
        gp = "git push";
        gl = "git log --oneline";
        gd = "git diff";
        gco = "git checkout";

        # System aliases
        grep = "grep --color=auto";
        rg = "rg --color=auto";
        ps = "ps aux";
        df = "df -h";
        du = "du -h";

        # NixOS rebuild aliases (match existing pattern)
        update = "sudo nixos-rebuild switch --flake /etc/nixos";
        build = "sudo nixos-rebuild build --flake /etc/nixos";
        nixtest = "sudo nixos-rebuild test --flake /etc/nixos";

        # Network aliases
        ports = "ss -tuln";
        myip = "curl -s ifconfig.me";

        # Docker aliases
        dps = "docker ps";
        dpa = "docker ps -a";
        dlogs = "docker logs";
        dshell = "docker exec -it";
      };

      # Interactive shell initialization
      interactiveShellInit = ''
        # Environment variables are now set system-wide
        # Add user bin to PATH (additional to system PATH)
        set -Ua fish_user_paths "$HOME/.local/bin"

        # Fast startup optimizations
        set -gx FISH_NO_UNICODE_BREAK 1
        set -gx FISH_NO_OLD_KEY_BINDINGS 1

        # History settings
        set -U fish_history_limit 10000

        # Color settings (more modern than default)
        set -x fish_color_autosuggestion brblack
        set -x fish_color_cancel -r
        set -x fish_color_command normal
        set -x fish_color_comment red
        set -x fish_color_cwd green
        set -x fish_color_cwd_root red
        set -x fish_color_end green
        set -x fish_color_error brred
        set -x fish_color_escape brcyan
        set -x fish_color_history_current --bold
        set -x fish_color_host normal
        set -x fish_color_host_remote yellow
        set -x fish_color_normal normal
        set -x fish_color_operator brcyan
        set -x fish_color_param cyan
        set -x fish_color_quote yellow
        set -x fish_color_redirection cyan --bold
        set -x fish_color_search_match white --background=brblack --bold
        set -x fish_color_selection white --background=brblack --bold
        set -x fish_color_status red
        set -x fish_color_user brgreen
        set -x fish_color_valid_path --underline
        set -x fish_key_bindings fish_default_key_bindings

        set -x fish_pager_color_background ""
        set -x fish_pager_color_completion normal
        set -x fish_pager_color_description yellow --italic
        set -x fish_pager_color_prefix normal --bold --underline
        set -x fish_pager_color_progress brwhite --background=cyan --bold
        set -x fish_pager_color_secondary_background ""
        set -x fish_pager_color_secondary_completion ""
        set -x fish_pager_color_secondary_description ""
        set -x fish_pager_color_secondary_prefix ""
        set -x fish_pager_color_selected_background -r
        set -x fish_pager_color_selected_completion ""
        set -x fish_pager_color_selected_description ""
        set -x fish_pager_color_selected_prefix ""
      '';

      # Login shell initialization
      loginShellInit = ''
        # Source any existing shell configuration files
        if test -d ~/.config/fish/conf.d
          for file in ~/.config/fish/conf.d/*.fish
            if test -f $file
              source $file
            end
          end
        end
      '';
    };

    # Starship Configuration
    programs.starship = {
      enable = true;
      settings = {
        # Basic formatting
        format = "$all";
        scan_timeout = 10; # Faster than default 30ms
        add_newline = false;

        # Performance: Disable slow modules by default
        disabled = [
          "aws"
          "gcloud"
          "openstack"
          "kubernetes"
          "docker"
          "docker_context"
        ];

        # Git status (optimized for speed)
        git_status = {
          ahead = "⇡";
          behind = "⇣";
          diverged = "⇕";
          conflicted = "✖";
          untracked = "•";
          stashed = "⚑";
          modified = "▲";
          staged = "●";
          renamed = "»";
          deleted = "✗";
        };

        # Git branch
        git_branch = {
          symbol = "🌿 ";
          truncation_length = 20;
          truncation_symbol = "…/";
        };

        # Directory (performance optimized)
        directory = {
          truncation_length = 3;
          truncation_symbol = "…/";
          truncate_to_repo = true;
        };

        # Command duration (only show for long commands)
        cmd_duration = {
          min_time = 500;
          format = "took [$duration]($style)";
        };

        # Node.js
        nodejs = {
          symbol = "📦 ";
          format = "via [$symbol$version]($style)";
        };

        # Python
        python = {
          symbol = "🐍 ";
          format = "via [$symbol$version]($style)";
        };

        # Rust
        rust = {
          symbol = "🦀 ";
          format = "via [$symbol$version]($style)";
        };

        # Go
        golang = {
          symbol = "🐹 ";
          format = "via [$symbol$version]($style)";
        };

        # Username (only show when not j_kro)
        username = {
          show_always = false;
          format = "[$user]($style)@";
        };

        # Hostname
        hostname = {
          format = "[$hostname]($style)";
        };

        # Battery (if available)
        battery = {
          full_symbol = "🔋";
          charging_symbol = "⚡️";
          discharging_symbol = "💀";
          unknown_symbol = "❓";
          empty_symbol = "🪫";
        };

        # Time
        time = {
          format = "THOOK[$time]($style)";
          time_format = "%H:%M:%S";
          utc_time_offset = "local";
        };

        # Kubernetes (only if context is set)
        kubernetes = {
          disabled = false;
          format = "on [⛵ $context]($style) in [$namespace]($style) ";
        };

        # Docker Context (only if available)
        docker_context = {
          format = "via [🐋 $context]($style)";
        };

        # Package (npm, cargo, etc.)
        package = {
          format = "is [📦 $version]($style)";
        };

        # Shell (show when using non-standard shells)
        shell = {
          format = "on [$symbol$version]($style)";
        };

        # Status (only show on error)
        status = {
          format = "[$symbol$status]($style)";
          pipestatus_format = "[$symbol$common_meaning($pipestatus)]($style)";
        };

        # Jobs (background processes)
        jobs = {
          format = "[$symbol$number]($style)";
        };
      };
    };

    # Note: SHELL is handled by Home Manager in home.nix
  };
}
