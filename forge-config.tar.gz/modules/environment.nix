{
  config,
  lib,
  ...
}: {
  # Centralized environment variables for consistency across the system
  environment.sessionVariables =
    {
      # Basic system variables
      EDITOR = "nvim";
      BROWSER = "zen";
      TERMINAL = "konsole";
      PAGER = "less";
      LESS = "-R --mouse --wheel-lines=3";

      # Path additions
      PATH = "$HOME/.local/bin:$PATH";

      # NVIDIA environment variables
      __NV_PRIME_RENDER_OFFLOAD = "1";
      __GL_SYNC_TO_VBLANK = "0";
      __GL_SHADER_DISK_CACHE = "1";
      __GL_SHADER_DISK_CACHE_PATH = "/tmp/nvidia-shader-cache";

      # DLSS and ray tracing optimizations
      NVDX_GL_COMPUTE_SHADER_STORAGE_IMAGE_EXTENDED = "1";
      NVDX_GL_SHADER_STORAGE_IMAGE_ATOMIC = "1";

      # Low latency gaming
      NVDX_INTEROP_FLIPABLE = "0";
      NVDX_INTEROP_BYTE_ADDRESSABLE = "1";

       # VR optimizations
       NVDX_INTEROP_DX_INTEROP2 = "1";
       # Temporary workaround: use software Vulkan until NVIDIA ICD is fixed
       VK_ICD_FILENAMES = "/run/opengl-driver/share/vulkan/icd.d/lvp_icd.x86_64.json";

      # NVENC specific optimizations
      NVDX_Capture_Vulkan_Enable = "1";
      NVDX_Capture_Enable = "1";
      NVDX_Encoder_Enable = "1";
      NVDX_Vulkan_Enable = "1";

      # Gaming and Wayland
      GBM_BACKEND = "nvidia-drm";
      __GLX_VENDOR_LIBRARY_NAME = "nvidia";
      WLR_NO_HARDWARE_CURSORS = "1";
      WLR_EGL_NO_MODIFIERS = "1";
      STEAM_RUNTIME = "1";
      NIXOS_OZONE_WL = "1";

      # DXVK for DirectX to Vulkan translation (AAGL games)
      DXVK_CONFIG_FILE = "/home/j_kro/.config/dxvk/dxvk.conf";
      DXVK_LOG_LEVEL = "none";
      DXVK_HUD = "0";

      # KDE Plasma environment
      XDG_CURRENT_DESKTOP = "KDE";
      KDE_SESSION_VERSION = "6";
      QT_QPA_PLATFORMTHEME = "kde";
      QT_STYLE_OVERRIDE = "kvantum";

      # System tray and desktop integration
      XDG_SESSION_DESKTOP = "KDE";
      DESKTOP_SESSION = "plasma";
      KDE_FULL_SESSION = "true";

      # Locale settings for Wine/AAGL compatibility (fixes keyboard input issues)
      LANG = lib.mkForce "en_CA.UTF-8";
      LC_ALL = lib.mkForce "en_CA.UTF-8";

       # DualSense controller environment variables - REQUIRED for Wine keyboard input
       SDL_JOYSTICK_HIDAPI_PS5 = "1"; # Critical for Wine keyboard handling
       SDL_JOYSTICK_HIDAPI_PS5_RUMBLE = "1"; # Enable rumble support

       # Wine hidraw support - keep disabled to prevent conflicts
       # WINEHIDRAW = "1"; # Interferes with keyboard input
    }
    // lib.optionalAttrs (config.age.secrets ? "claude-api-key") {
      # Claude Code
      ANTHROPIC_AUTH_TOKEN_FILE = config.age.secrets.claude-api-key.path;
      API_TIMEOUT_MS = "3000000";
      ANTHROPIC_BASE_URL = "https://vanchin.streamlake.ai/api/gateway/coding/kat-coder-pro-v1/claude-code-proxy";
    };
}
