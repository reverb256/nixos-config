#!/bin/bash
# KDE Plasma Fix Script - Resolves window management issues
# Run this after applying the NixOS configuration changes

set -e

echo "🔧 KDE Plasma Window Management Fix"
echo "===================================="

# 1. Rebuild the system
echo ""
echo "📦 Step 1: Rebuilding NixOS configuration..."
echo "   Command: sudo nixos-rebuild switch --flake /etc/nixos"
sudo nixos-rebuild switch --flake /etc/nixos || {
    echo "❌ ERROR: NixOS rebuild failed!"
    echo "   Please check the configuration for errors."
    exit 1
}

# 2. Restart SDDM
echo ""
echo "🔄 Step 2: Restarting SDDM display manager..."
sudo systemctl restart sddm.service || {
    echo "⚠️  Warning: Could not restart SDDM"
    echo "   You may need to restart your display manager manually"
}

# 3. Restart Plasma (if logged in)
echo ""
echo "🔄 Step 3: Restarting Plasma session..."
if systemctl is-active --user plasma-plasma.desktop > /dev/null 2>&1; then
    echo "   Restarting Plasma..."
    # Kill all plasma processes and restart
    killall -9 plasmashell kded5 kwin_x11 kwin_wayland 2>/dev/null || true
    sleep 2
    # Start plasma shell again
    kstart5 plasmashell &
    echo "✅ Plasma session restarted"
else
    echo "⚠️  No active Plasma session found"
    echo "   The fix will take effect on your next login"
fi

# 4. Clear KDE cache
echo ""
echo "🧹 Step 4: Clearing KDE cache..."
rm -rf ~/.cache/plasma* 2>/dev/null || true
rm -rf ~/.cache/kioexec* 2>/dev/null || true
echo "✅ KDE cache cleared"

# 5. Reset Plasma configuration (optional)
echo ""
echo "🔧 Step 5: Plasma configuration options"
echo "   If issues persist, you may need to reset Plasma settings:"
echo "   1. Press Alt+F2 and type: kcmshell6 kcm_plasmawindowmanagement"
echo "   2. Go to Window Management → Window Behavior"
echo "   3. Check 'Focus' and 'Activation' settings"
echo "   4. Ensure 'Virtual Desktops' are configured correctly"
echo "   5. Check 'Screen Edges' for multi-monitor setups"

echo ""
echo "✅ KDE Plasma fix complete!"
echo ""
echo "📋 Summary of fixes applied:"
echo "   ✓ Added xdg-desktop-portal-kde for window tracking"
echo "   ✓ Added KDE environment variables (QT_QPA_PLATFORM, etc.)"
echo "   ✓ Enabled NVIDIA modesetting for better stability"
echo "   ✓ Enabled SDDM Wayland support"
echo "   ✓ Added KDE Plasma configuration options"
echo ""
echo "🔄 Please log out and log back in for all changes to take full effect"
echo "   If windows still disappear, try restarting your Plasma session"
